"use client"

import { create } from "zustand"
import { persist } from "zustand/middleware"

interface CartItem {
  id: string
  name: string
  price: number
  image: string
  quantity: number
  color?: string
  size?: string
}

interface CartStore {
  items: CartItem[]
  addItem: (item: CartItem) => void
  removeItem: (id: string) => void
  updateQuantity: (id: string, quantity: number) => void
  clearCart: () => void
  itemCount: number
}

export const useCart = create<CartStore>()(
  persist(
    (set, get) => ({
      items: [],
      itemCount: 0,
      addItem: (item) => {
        const currentItems = get().items
        const existingItem = currentItems.find((i) => i.id === item.id)

        if (existingItem) {
          // Nếu sản phẩm đã tồn tại, tăng số lượng
          set({
            items: currentItems.map((i) => (i.id === item.id ? { ...i, quantity: i.quantity + item.quantity } : i)),
            itemCount: get().itemCount + item.quantity,
          })
        } else {
          // Nếu sản phẩm chưa tồn tại, thêm mới
          set({
            items: [...currentItems, item],
            itemCount: get().itemCount + item.quantity,
          })
        }
      },
      removeItem: (id) => {
        const currentItems = get().items
        const itemToRemove = currentItems.find((i) => i.id === id)

        if (itemToRemove) {
          set({
            items: currentItems.filter((i) => i.id !== id),
            itemCount: get().itemCount - itemToRemove.quantity,
          })
        }
      },
      updateQuantity: (id, quantity) => {
        const currentItems = get().items
        const oldItem = currentItems.find((i) => i.id === id)

        if (oldItem) {
          const quantityDiff = quantity - oldItem.quantity

          set({
            items: currentItems.map((i) => (i.id === id ? { ...i, quantity } : i)),
            itemCount: get().itemCount + quantityDiff,
          })
        }
      },
      clearCart: () => {
        set({ items: [], itemCount: 0 })
      },
    }),
    {
      name: "cart-storage",
    },
  ),
)
