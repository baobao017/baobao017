"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import Image from "next/image"
import { ArrowRight } from "lucide-react"
import { LoadingIndicator } from "@/components/loading-indicator"

// Mock data - Thay thế bằng dữ liệu thực từ API
const collections = [
  {
    id: "ao",
    name: "Áo",
    description: "Áo thun, áo sơ mi, áo khoác và nhiều loại áo khác",
    image: "/placeholder.svg?height=400&width=300",
    itemCount: 120,
  },
  {
    id: "quan",
    name: "Quần",
    description: "Quần jean, quần tây, quần short và nhiều loại quần khác",
    image: "/placeholder.svg?height=400&width=300",
    itemCount: 85,
  },
  {
    id: "vay-dam",
    name: "Váy đầm",
    description: "Váy liền, chân váy, đầm dự tiệc và nhiều loại váy đầm khác",
    image: "/placeholder.svg?height=400&width=300",
    itemCount: 95,
  },
  {
    id: "do-bo",
    name: "Đồ bộ",
    description: "Đồ bộ mặc nhà, đồ thể thao và nhiều loại đồ bộ khác",
    image: "/placeholder.svg?height=400&width=300",
    itemCount: 50,
  },
]

export default function CollectionGrid() {
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    // Giả lập fetch dữ liệu
    const fetchCollections = async () => {
      await new Promise((resolve) => setTimeout(resolve, 800))
      setIsLoading(false)
    }

    fetchCollections()
  }, [])

  if (isLoading) {
    return <LoadingIndicator />
  }

  return (
    <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
      {collections.map((collection) => (
        <Link
          key={collection.id}
          href={`/bo-suu-tap/${collection.id}`}
          className="group relative overflow-hidden rounded-lg"
        >
          <div className="relative aspect-[3/4] w-full overflow-hidden rounded-lg">
            <Image
              src={collection.image || "/placeholder.svg"}
              alt={collection.name}
              fill
              className="object-cover transition-transform duration-300 group-hover:scale-105"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent"></div>
            <div className="absolute bottom-0 left-0 right-0 p-4">
              <h3 className="text-lg font-bold text-white">{collection.name}</h3>
              <p className="text-sm text-white/80">{collection.itemCount} sản phẩm</p>
              <div className="mt-2 flex items-center text-white text-sm font-medium">
                <span>Xem ngay</span>
                <ArrowRight className="ml-1 h-4 w-4 transition-transform group-hover:translate-x-1" />
              </div>
            </div>
          </div>
        </Link>
      ))}
    </div>
  )
}
