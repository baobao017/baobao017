"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import { X } from "lucide-react"

const promos = [
  {
    id: 1,
    text: "Miễn phí vận chuyển cho đơn hàng từ 300K",
    link: "/khuyen-mai/mien-phi-van-chuyen",
  },
  {
    id: 2,
    text: "Giảm 10% cho đơn hàng đầu tiên - Mã: HELLO10",
    link: "/khuyen-mai/giam-10-phan-tram",
  },
  {
    id: 3,
    text: "Mua 2 tặng 1 cho tất cả phụ kiện",
    link: "/khuyen-mai/mua-2-tang-1",
  },
]

export default function PromoBanner() {
  const [currentPromo, setCurrentPromo] = useState(0)
  const [isVisible, setIsVisible] = useState(true)

  // Tự động chuyển banner
  useEffect(() => {
    if (!isVisible) return

    const interval = setInterval(() => {
      setCurrentPromo((prev) => (prev + 1) % promos.length)
    }, 5000)

    return () => clearInterval(interval)
  }, [isVisible])

  if (!isVisible) return null

  return (
    <div className="bg-black text-white py-2 relative">
      <div className="container px-4">
        <div className="flex items-center justify-center text-center">
          <Link href={promos[currentPromo].link} className="text-sm hover:underline">
            {promos[currentPromo].text}
          </Link>
          <button
            onClick={() => setIsVisible(false)}
            className="absolute right-4 top-1/2 transform -translate-y-1/2"
            aria-label="Đóng banner"
          >
            <X className="h-4 w-4" />
          </button>
        </div>
      </div>
    </div>
  )
}
