"use client"

import { useState, useEffect } from "react"
import { ProductCard } from "@/components/product-card"
import { LoadingIndicator } from "@/components/loading-indicator"

// Mock data - Thay thế bằng dữ liệu thực từ API
const featuredProducts = [
  {
    id: "1",
    name: "Áo Thun Unisex Cotton Form Rộng",
    price: 199000,
    salePrice: 149000,
    image: "/placeholder.svg?height=300&width=300",
    discount: 25,
    isNew: true,
  },
  {
    id: "2",
    name: "Quần Jean Nam Slim Fit",
    price: 399000,
    salePrice: 399000,
    image: "/placeholder.svg?height=300&width=300",
    discount: 0,
    isNew: false,
  },
  {
    id: "3",
    name: "Áo Khoác Denim Unisex",
    price: 499000,
    salePrice: 399000,
    image: "/placeholder.svg?height=300&width=300",
    discount: 20,
    isNew: true,
  },
  {
    id: "4",
    name: "Áo Thun Nữ Form Rộng",
    price: 189000,
    salePrice: 159000,
    image: "/placeholder.svg?height=300&width=300",
    discount: 16,
    isNew: false,
  },
  {
    id: "5",
    name: "Váy Liền Nữ Dáng Xòe",
    price: 350000,
    salePrice: 299000,
    image: "/placeholder.svg?height=300&width=300",
    discount: 15,
    isNew: true,
  },
  {
    id: "6",
    name: "Áo Sơ Mi Nam Dài Tay",
    price: 299000,
    salePrice: 249000,
    image: "/placeholder.svg?height=300&width=300",
    discount: 17,
    isNew: false,
  },
]

interface FeaturedProductsProps {
  layout?: "grid" | "carousel"
  limit?: number
}

export default function FeaturedProducts({ layout = "grid", limit = 6 }: FeaturedProductsProps) {
  const [products, setProducts] = useState<any[]>([])
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    // Giả lập fetch dữ liệu
    const fetchProducts = async () => {
      setIsLoading(true)
      // Trong thực tế, gọi API để lấy sản phẩm nổi bật
      await new Promise((resolve) => setTimeout(resolve, 800))
      setProducts(featuredProducts.slice(0, limit))
      setIsLoading(false)
    }

    fetchProducts()
  }, [limit])

  if (isLoading) {
    return <LoadingIndicator />
  }

  if (layout === "carousel") {
    return (
      <div className="relative">
        <div className="flex overflow-x-auto scrollbar-hide pb-4 -mx-4 px-4 space-x-4">
          {products.map((product) => (
            <div key={product.id} className="w-40 md:w-64 flex-shrink-0">
              <ProductCard product={product} />
            </div>
          ))}
        </div>
      </div>
    )
  }

  return (
    <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
      {products.map((product) => (
        <ProductCard key={product.id} product={product} />
      ))}
    </div>
  )
}
