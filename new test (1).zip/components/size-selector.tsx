"use client"

import { useState } from "react"
import { cn } from "@/lib/utils"

interface SizeSelectorProps {
  sizes: string[]
  onChange?: (size: string) => void
}

export function SizeSelector({ sizes, onChange }: SizeSelectorProps) {
  const [selectedSize, setSelectedSize] = useState<string | null>(null)

  const handleSizeChange = (size: string) => {
    setSelectedSize(size)
    if (onChange) {
      onChange(size)
    }
  }

  return (
    <div className="flex flex-wrap gap-2">
      {sizes.map((size) => (
        <button
          key={size}
          type="button"
          className={cn(
            "min-w-[3rem] rounded-md border px-3 py-2 text-sm font-medium transition-colors",
            selectedSize === size
              ? "border-primary bg-primary/10 text-primary"
              : "border-gray-200 bg-white text-gray-900 hover:bg-gray-50",
          )}
          onClick={() => handleSizeChange(size)}
        >
          {size}
        </button>
      ))}
    </div>
  )
}
