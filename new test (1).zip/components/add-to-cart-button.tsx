"use client"

import { useState } from "react"
import { ShoppingCart } from "lucide-react"
import { Button } from "@/components/ui/button"
import { useToast } from "@/components/ui/use-toast"
import { cn } from "@/lib/utils"

interface AddToCartButtonProps {
  productId: string
  className?: string
  variant?: "default" | "outline" | "secondary"
  size?: "default" | "sm" | "lg" | "icon"
}

export function AddToCartButton({ productId, className, variant = "default", size = "default" }: AddToCartButtonProps) {
  const [isLoading, setIsLoading] = useState(false)
  const { toast } = useToast()

  const handleAddToCart = async () => {
    setIsLoading(true)

    // Giả lập thêm vào giỏ hàng
    await new Promise((resolve) => setTimeout(resolve, 600))

    toast({
      title: "Đã thêm vào giỏ hàng",
      description: "Sản phẩm đã được thêm vào giỏ hàng của bạn.",
    })

    setIsLoading(false)
  }

  return (
    <Button
      variant={variant}
      size={size}
      className={cn("gap-2", className)}
      onClick={handleAddToCart}
      disabled={isLoading}
    >
      <ShoppingCart className="h-5 w-5" />
      {size !== "icon" && (isLoading ? "Đang thêm..." : "Thêm vào giỏ")}
    </Button>
  )
}
