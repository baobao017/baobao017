"use client"

import Link from "next/link"
import { usePathname } from "next/navigation"
import { Home, Search, Heart, ShoppingBag, User } from "lucide-react"
import { cn } from "@/lib/utils"

const navItems = [
  {
    label: "Trang chủ",
    href: "/",
    icon: Home,
  },
  {
    label: "Tìm kiếm",
    href: "/tim-kiem",
    icon: Search,
  },
  {
    label: "Yêu thích",
    href: "/yeu-thich",
    icon: Heart,
  },
  {
    label: "Giỏ hàng",
    href: "/gio-hang",
    icon: ShoppingBag,
    badge: 5,
  },
  {
    label: "Tài khoản",
    href: "/tai-khoan",
    icon: User,
  },
]

export default function MobileNavigation() {
  const pathname = usePathname()

  return (
    <div className="fixed bottom-0 left-0 right-0 z-50 bg-white border-t h-16 md:hidden">
      <div className="grid grid-cols-5 h-full">
        {navItems.map((item) => {
          const isActive = pathname === item.href

          return (
            <Link
              key={item.href}
              href={item.href}
              className={cn("flex flex-col items-center justify-center", isActive ? "text-primary" : "text-gray-500")}
            >
              <div className="relative">
                <item.icon className="h-6 w-6" />
                {item.badge && (
                  <span className="absolute -top-1 -right-1 bg-primary text-primary-foreground text-xs rounded-full h-4 w-4 flex items-center justify-center">
                    {item.badge}
                  </span>
                )}
              </div>
              <span className="text-xs mt-1">{item.label}</span>
            </Link>
          )
        })}
      </div>
    </div>
  )
}
