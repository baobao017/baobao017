"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import { CheckCircle, ShoppingBag, FileText, Home } from "lucide-react"
import { Button } from "@/components/ui/button"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"

interface OrderSuccessDialogProps {
  open: boolean
  onOpenChange: (open: boolean) => void
}

export function OrderSuccessDialog({ open, onOpenChange }: OrderSuccessDialogProps) {
  const [orderNumber, setOrderNumber] = useState("")

  useEffect(() => {
    if (open) {
      // Tạo mã đơn hàng ngẫu nhiên
      const randomOrderNumber = `DH${Math.floor(100000 + Math.random() * 900000)}`
      setOrderNumber(randomOrderNumber)
    }
  }, [open])

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader className="flex flex-col items-center text-center">
          <div className="bg-green-100 p-3 rounded-full mb-4">
            <CheckCircle className="h-10 w-10 text-green-600" />
          </div>
          <DialogTitle className="text-2xl">Đặt hàng thành công!</DialogTitle>
          <DialogDescription>Cảm ơn bạn đã mua sắm tại shop của chúng tôi</DialogDescription>
        </DialogHeader>

        <div className="space-y-4 py-4">
          <div className="bg-gray-50 p-4 rounded-lg">
            <div className="text-center mb-2">
              <span className="text-sm text-gray-500">Mã đơn hàng của bạn</span>
            </div>
            <div className="text-center font-bold text-xl">{orderNumber}</div>
          </div>

          <p className="text-center text-sm text-gray-500">
            Chúng tôi đã gửi email xác nhận đơn hàng với các chi tiết và thông tin theo dõi đơn hàng của bạn.
          </p>
        </div>

        <DialogFooter className="flex-col sm:flex-col gap-2">
          <Button asChild className="w-full">
            <Link href={`/tai-khoan/don-hang/${orderNumber}`}>
              <FileText className="mr-2 h-4 w-4" />
              Xem chi tiết đơn hàng
            </Link>
          </Button>

          <Button variant="outline" asChild className="w-full">
            <Link href="/danh-muc/tat-ca">
              <ShoppingBag className="mr-2 h-4 w-4" />
              Tiếp tục mua sắm
            </Link>
          </Button>

          <Button variant="ghost" asChild className="w-full">
            <Link href="/">
              <Home className="mr-2 h-4 w-4" />
              Về trang chủ
            </Link>
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}
