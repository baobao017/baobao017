"use client"

import { useState } from "react"
import Link from "next/link"
import { Menu, ChevronRight, Home, ShoppingBag, Heart, User, LogIn, Settings, HelpCircle, LogOut } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetTrigger } from "@/components/ui/sheet"

const mainLinks = [
  { label: "Trang chủ", href: "/", icon: Home },
  { label: "Sản phẩm", href: "/danh-muc/tat-ca", icon: ShoppingBag },
  { label: "Yêu thích", href: "/yeu-thich", icon: Heart },
  { label: "Tài khoản", href: "/tai-khoan", icon: User },
]

const collections = [
  { label: "Áo", href: "/bo-suu-tap/ao" },
  { label: "Quần", href: "/bo-suu-tap/quan" },
  { label: "Váy đầm", href: "/bo-suu-tap/vay-dam" },
  { label: "Đồ bộ", href: "/bo-suu-tap/do-bo" },
]

const accountLinks = [
  { label: "Đăng nhập", href: "/dang-nhap", icon: LogIn },
  { label: "Cài đặt", href: "/cai-dat", icon: Settings },
  { label: "Trợ giúp", href: "/tro-giup", icon: HelpCircle },
]

export default function SideMenu() {
  const [open, setOpen] = useState(false)
  const isLoggedIn = false // Thay đổi khi có hệ thống đăng nhập

  return (
    <Sheet open={open} onOpenChange={setOpen}>
      <SheetTrigger asChild>
        <Button variant="ghost" size="icon">
          <Menu className="h-6 w-6" />
          <span className="sr-only">Menu</span>
        </Button>
      </SheetTrigger>
      <SheetContent side="left" className="w-[300px] sm:w-[350px] p-0">
        <SheetHeader className="border-b p-4">
          <SheetTitle className="text-left">Menu</SheetTitle>
        </SheetHeader>

        <div className="overflow-y-auto h-[calc(100vh-60px)]">
          {/* Main links */}
          <div className="p-4">
            <ul className="space-y-2">
              {mainLinks.map((link) => (
                <li key={link.href}>
                  <Link
                    href={link.href}
                    className="flex items-center py-2 hover:text-primary"
                    onClick={() => setOpen(false)}
                  >
                    <link.icon className="h-5 w-5 mr-3" />
                    <span>{link.label}</span>
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Collections */}
          <div className="p-4 border-t">
            <h3 className="font-medium mb-3">Bộ sưu tập</h3>
            <ul className="space-y-2">
              {collections.map((collection) => (
                <li key={collection.href}>
                  <Link
                    href={collection.href}
                    className="flex items-center justify-between py-2 hover:text-primary"
                    onClick={() => setOpen(false)}
                  >
                    <span>{collection.label}</span>
                    <ChevronRight className="h-4 w-4" />
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Account */}
          <div className="p-4 border-t">
            <h3 className="font-medium mb-3">Tài khoản</h3>
            <ul className="space-y-2">
              {isLoggedIn ? (
                <>
                  <li>
                    <Link
                      href="/tai-khoan"
                      className="flex items-center py-2 hover:text-primary"
                      onClick={() => setOpen(false)}
                    >
                      <User className="h-5 w-5 mr-3" />
                      <span>Thông tin tài khoản</span>
                    </Link>
                  </li>
                  <li>
                    <button
                      className="flex items-center py-2 hover:text-primary w-full text-left"
                      onClick={() => {
                        // Xử lý đăng xuất
                        setOpen(false)
                      }}
                    >
                      <LogOut className="h-5 w-5 mr-3" />
                      <span>Đăng xuất</span>
                    </button>
                  </li>
                </>
              ) : (
                accountLinks.map((link) => (
                  <li key={link.href}>
                    <Link
                      href={link.href}
                      className="flex items-center py-2 hover:text-primary"
                      onClick={() => setOpen(false)}
                    >
                      <link.icon className="h-5 w-5 mr-3" />
                      <span>{link.label}</span>
                    </Link>
                  </li>
                ))
              )}
            </ul>
          </div>
        </div>
      </SheetContent>
    </Sheet>
  )
}
