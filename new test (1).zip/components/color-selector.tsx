"use client"

import { useState } from "react"
import { Check } from "lucide-react"
import { cn } from "@/lib/utils"

interface ColorSelectorProps {
  colors: string[]
  onChange?: (color: string) => void
}

// Ánh xạ tên màu sang mã màu Tailwind
const colorMap: Record<string, string> = {
  Đen: "bg-black",
  Trắng: "bg-white",
  Xám: "bg-gray-400",
  "Xanh Navy": "bg-blue-900",
  Đỏ: "bg-red-600",
  "Xanh lá": "bg-green-600",
  Vàng: "bg-yellow-400",
  Hồng: "bg-pink-400",
  Tím: "bg-purple-600",
  Cam: "bg-orange-500",
  Nâu: "bg-amber-800",
  Be: "bg-amber-100",
}

export function ColorSelector({ colors, onChange }: ColorSelectorProps) {
  const [selectedColor, setSelectedColor] = useState<string | null>(null)

  const handleColorChange = (color: string) => {
    setSelectedColor(color)
    if (onChange) {
      onChange(color)
    }
  }

  return (
    <div className="flex flex-wrap gap-2">
      {colors.map((color) => {
        const bgColorClass = colorMap[color] || "bg-gray-200"
        const isWhite = color === "Trắng"

        return (
          <button
            key={color}
            type="button"
            className={cn(
              "group relative h-10 w-10 rounded-full border-2 transition-all",
              selectedColor === color ? "border-primary" : "border-transparent hover:border-gray-300",
            )}
            onClick={() => handleColorChange(color)}
            title={color}
          >
            <span
              className={cn("absolute inset-1 rounded-full", bgColorClass, isWhite ? "border border-gray-200" : "")}
            >
              {selectedColor === color && (
                <Check
                  className={cn(
                    "absolute left-1/2 top-1/2 h-5 w-5 -translate-x-1/2 -translate-y-1/2",
                    isWhite ? "text-black" : "text-white",
                  )}
                />
              )}
            </span>
            <span className="sr-only">{color}</span>
          </button>
        )
      })}
    </div>
  )
}
