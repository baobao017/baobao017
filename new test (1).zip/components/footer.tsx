import Link from "next/link"
import { Facebook, Instagram, Youtube, MapPin, Phone, Mail } from "lucide-react"

export default function Footer() {
  return (
    <footer className="bg-gray-100 pt-8 pb-20 md:pb-8 mt-8">
      <div className="container px-4">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          {/* Thông tin cửa hàng */}
          <div>
            <h3 className="font-bold text-lg mb-4">ThoiTrangViet</h3>
            <p className="text-sm text-gray-600 mb-4">
              Thời trang Việt Nam chất lượng cao với giá cả phải chăng. Chúng tôi cam kết mang đến những sản phẩm tốt
              nhất cho khách hàng.
            </p>
            <div className="flex space-x-4">
              <Link href="https://facebook.com" className="text-gray-600 hover:text-primary">
                <Facebook className="h-5 w-5" />
                <span className="sr-only">Facebook</span>
              </Link>
              <Link href="https://instagram.com" className="text-gray-600 hover:text-primary">
                <Instagram className="h-5 w-5" />
                <span className="sr-only">Instagram</span>
              </Link>
              <Link href="https://youtube.com" className="text-gray-600 hover:text-primary">
                <Youtube className="h-5 w-5" />
                <span className="sr-only">Youtube</span>
              </Link>
            </div>
          </div>

          {/* Liên kết nhanh */}
          <div>
            <h3 className="font-bold mb-4">Liên kết nhanh</h3>
            <ul className="space-y-2 text-sm">
              <li>
                <Link href="/gioi-thieu" className="text-gray-600 hover:text-primary">
                  Giới thiệu
                </Link>
              </li>
              <li>
                <Link href="/chinh-sach-doi-tra" className="text-gray-600 hover:text-primary">
                  Chính sách đổi trả
                </Link>
              </li>
              <li>
                <Link href="/dieu-khoan-dich-vu" className="text-gray-600 hover:text-primary">
                  Điều khoản dịch vụ
                </Link>
              </li>
              <li>
                <Link href="/chinh-sach-bao-mat" className="text-gray-600 hover:text-primary">
                  Chính sách bảo mật
                </Link>
              </li>
              <li>
                <Link href="/cau-hoi-thuong-gap" className="text-gray-600 hover:text-primary">
                  Câu hỏi thường gặp
                </Link>
              </li>
            </ul>
          </div>

          {/* Danh mục sản phẩm */}
          <div>
            <h3 className="font-bold mb-4">Danh mục sản phẩm</h3>
            <ul className="space-y-2 text-sm">
              <li>
                <Link href="/bo-suu-tap/ao" className="text-gray-600 hover:text-primary">
                  Áo
                </Link>
              </li>
              <li>
                <Link href="/bo-suu-tap/quan" className="text-gray-600 hover:text-primary">
                  Quần
                </Link>
              </li>
              <li>
                <Link href="/bo-suu-tap/vay-dam" className="text-gray-600 hover:text-primary">
                  Váy đầm
                </Link>
              </li>
              <li>
                <Link href="/bo-suu-tap/do-bo" className="text-gray-600 hover:text-primary">
                  Đồ bộ
                </Link>
              </li>
              <li>
                <Link href="/bo-suu-tap/phu-kien" className="text-gray-600 hover:text-primary">
                  Phụ kiện
                </Link>
              </li>
            </ul>
          </div>

          {/* Liên hệ */}
          <div>
            <h3 className="font-bold mb-4">Liên hệ</h3>
            <ul className="space-y-3 text-sm">
              <li className="flex items-start">
                <MapPin className="h-5 w-5 text-primary mr-2 mt-0.5" />
                <span className="text-gray-600">123 Đường ABC, Quận 1, TP. Hồ Chí Minh</span>
              </li>
              <li className="flex items-center">
                <Phone className="h-5 w-5 text-primary mr-2" />
                <span className="text-gray-600">0123 456 789</span>
              </li>
              <li className="flex items-center">
                <Mail className="h-5 w-5 text-primary mr-2" />
                <span className="text-gray-600">info@thoitrangviet.com</span>
              </li>
            </ul>
          </div>
        </div>

        <div className="border-t mt-8 pt-6 text-center text-sm text-gray-600">
          <p>&copy; {new Date().getFullYear()} ThoiTrangViet. Tất cả các quyền được bảo lưu.</p>
        </div>
      </div>
    </footer>
  )
}
