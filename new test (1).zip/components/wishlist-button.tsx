"use client"

import { useState } from "react"
import { Heart } from "lucide-react"
import { Button } from "@/components/ui/button"
import { useToast } from "@/components/ui/use-toast"
import { cn } from "@/lib/utils"

interface WishlistButtonProps {
  productId: string
  className?: string
}

export function WishlistButton({ productId, className }: WishlistButtonProps) {
  const [isInWishlist, setIsInWishlist] = useState(false)
  const [isLoading, setIsLoading] = useState(false)
  const { toast } = useToast()

  const toggleWishlist = async () => {
    setIsLoading(true)

    // Giả lập thêm/xóa khỏi danh sách yêu thích
    await new Promise((resolve) => setTimeout(resolve, 500))

    const newState = !isInWishlist
    setIsInWishlist(newState)

    toast({
      title: newState ? "Đã thêm vào yêu thích" : "Đã xóa khỏi yêu thích",
      description: newState
        ? "Sản phẩm đã được thêm vào danh sách yêu thích của bạn."
        : "Sản phẩm đã được xóa khỏi danh sách yêu thích của bạn.",
    })

    setIsLoading(false)
  }

  return (
    <Button
      variant="outline"
      size="icon"
      className={cn(
        "h-11 w-11 transition-colors",
        isInWishlist && "bg-red-50 text-red-500 border-red-200 hover:bg-red-100 hover:text-red-600",
        className,
      )}
      onClick={toggleWishlist}
      disabled={isLoading}
      aria-label={isInWishlist ? "Xóa khỏi yêu thích" : "Thêm vào yêu thích"}
    >
      <Heart className={cn("h-5 w-5 transition-all", isInWishlist && "fill-current")} />
    </Button>
  )
}
