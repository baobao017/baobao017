"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import Image from "next/image"
import { Clock, ArrowRight } from "lucide-react"
import { Badge } from "@/components/ui/badge"

// Dữ liệu mẫu cho Flash Sale
const flashSaleProducts = [
  {
    id: 1,
    name: "Áo Thun Unisex",
    originalPrice: 299000,
    salePrice: 149000,
    discount: 50,
    image: "/placeholder.svg?height=200&width=200",
  },
  {
    id: 2,
    name: "Quần Jean Nữ Ống Rộng",
    originalPrice: 450000,
    salePrice: 299000,
    discount: 33,
    image: "/placeholder.svg?height=200&width=200",
  },
  {
    id: 3,
    name: "Áo Sơ Mi Nam Dài Tay",
    originalPrice: 399000,
    salePrice: 199000,
    discount: 50,
    image: "/placeholder.svg?height=200&width=200",
  },
  {
    id: 4,
    name: "Váy Đầm Dự Tiệc",
    originalPrice: 799000,
    salePrice: 499000,
    discount: 38,
    image: "/placeholder.svg?height=200&width=200",
  },
]

export default function FlashSale() {
  const [timeLeft, setTimeLeft] = useState({
    hours: 5,
    minutes: 30,
    seconds: 0,
  })

  // Đếm ngược thời gian
  useEffect(() => {
    const timer = setInterval(() => {
      setTimeLeft((prev) => {
        if (prev.seconds > 0) {
          return { ...prev, seconds: prev.seconds - 1 }
        } else if (prev.minutes > 0) {
          return { ...prev, minutes: prev.minutes - 1, seconds: 59 }
        } else if (prev.hours > 0) {
          return { hours: prev.hours - 1, minutes: 59, seconds: 59 }
        }
        return prev
      })
    }, 1000)

    return () => clearInterval(timer)
  }, [])

  return (
    <section className="px-4 py-6">
      <div className="flex justify-between items-center mb-4">
        <div className="flex items-center gap-2">
          <h2 className="text-xl font-bold text-red-600">FLASH SALE</h2>
          <div className="flex items-center bg-red-100 text-red-600 rounded-md px-2 py-1">
            <Clock className="h-4 w-4 mr-1" />
            <span className="text-sm font-medium">
              {String(timeLeft.hours).padStart(2, "0")}:{String(timeLeft.minutes).padStart(2, "0")}:
              {String(timeLeft.seconds).padStart(2, "0")}
            </span>
          </div>
        </div>

        <Link href="/flash-sale" className="text-sm text-primary flex items-center">
          Xem tất cả
          <ArrowRight className="h-4 w-4 ml-1" />
        </Link>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        {flashSaleProducts.map((product) => (
          <Link
            href={`/san-pham/${product.id}`}
            key={product.id}
            className="group relative bg-white rounded-lg border overflow-hidden shadow-sm hover:shadow-md transition-shadow"
          >
            <Badge className="absolute top-2 left-2 bg-red-600 hover:bg-red-700 z-10">-{product.discount}%</Badge>

            <div className="relative aspect-square">
              <Image
                src={product.image || "/placeholder.svg"}
                alt={product.name}
                fill
                className="object-cover group-hover:scale-105 transition-transform"
                sizes="(max-width: 768px) 50vw, 25vw"
              />
            </div>

            <div className="p-2">
              <h3 className="text-sm font-medium line-clamp-1">{product.name}</h3>
              <div className="flex items-center gap-2 mt-1">
                <span className="text-red-600 font-bold">{product.salePrice.toLocaleString()}₫</span>
                <span className="text-gray-400 text-xs line-through">{product.originalPrice.toLocaleString()}₫</span>
              </div>

              <div className="mt-2 h-1.5 bg-gray-200 rounded-full overflow-hidden">
                <div
                  className="h-full bg-red-600 rounded-full"
                  style={{ width: `${Math.floor(Math.random() * 50) + 50}%` }}
                ></div>
              </div>
              <p className="text-xs text-gray-500 mt-1">Đã bán {Math.floor(Math.random() * 50) + 10}</p>
            </div>
          </Link>
        ))}
      </div>
    </section>
  )
}
