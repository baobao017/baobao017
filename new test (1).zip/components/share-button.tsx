"use client"
import { Share2, Copy, Facebook, Twitter } from "lucide-react"
import { Button } from "@/components/ui/button"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import { useToast } from "@/components/ui/use-toast"
import { cn } from "@/lib/utils"

interface ShareButtonProps {
  productId: string
  className?: string
}

export function ShareButton({ productId, className }: ShareButtonProps) {
  const { toast } = useToast()

  const handleCopyLink = () => {
    // Trong thực tế, lấy URL hiện tại hoặc tạo URL sản phẩm
    const url = window.location.href
    navigator.clipboard.writeText(url)

    toast({
      title: "Đã sao chép",
      description: "Đường dẫn đã được sao chép vào clipboard.",
    })
  }

  const handleShare = (platform: string) => {
    // Trong thực tế, tạo URL chia sẻ cho từng nền tảng
    const url = window.location.href
    const title = "Xem sản phẩm này trên shop của chúng tôi!"

    let shareUrl = ""

    switch (platform) {
      case "facebook":
        shareUrl = `https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(url)}`
        break
      case "twitter":
        shareUrl = `https://twitter.com/intent/tweet?url=${encodeURIComponent(url)}&text=${encodeURIComponent(title)}`
        break
      default:
        return
    }

    window.open(shareUrl, "_blank", "width=600,height=400")
  }

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button variant="outline" size="icon" className={cn("h-11 w-11", className)} aria-label="Chia sẻ sản phẩm">
          <Share2 className="h-5 w-5" />
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end">
        <DropdownMenuItem onClick={handleCopyLink}>
          <Copy className="mr-2 h-4 w-4" />
          <span>Sao chép liên kết</span>
        </DropdownMenuItem>
        <DropdownMenuItem onClick={() => handleShare("facebook")}>
          <Facebook className="mr-2 h-4 w-4" />
          <span>Chia sẻ lên Facebook</span>
        </DropdownMenuItem>
        <DropdownMenuItem onClick={() => handleShare("twitter")}>
          <Twitter className="mr-2 h-4 w-4" />
          <span>Chia sẻ lên Twitter</span>
        </DropdownMenuItem>
      </DropdownMenuContent>
    </DropdownMenu>
  )
}
