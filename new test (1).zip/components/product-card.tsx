"use client"

import type React from "react"

import { useState } from "react"
import Image from "next/image"
import Link from "next/link"
import { Heart, ShoppingBag } from "lucide-react"

import { useCart } from "@/hooks/use-cart"

interface ProductCardProps {
  product: {
    id: string
    name: string
    price: number
    salePrice?: number
    image: string
    discount?: number
    isNew?: boolean
  }
}

export function ProductCard({ product }: ProductCardProps) {
  const [isLoading, setIsLoading] = useState(true)
  const [isFavorite, setIsFavorite] = useState(false)
  const { addItem } = useCart()

  const handleAddToCart = (e: React.MouseEvent) => {
    e.preventDefault()
    e.stopPropagation()

    addItem({
      id: product.id,
      name: product.name,
      price: product.salePrice || product.price,
      image: product.image,
      quantity: 1,
    })
  }

  const toggleFavorite = (e: React.MouseEvent) => {
    e.preventDefault()
    e.stopPropagation()
    setIsFavorite(!isFavorite)
  }

  const formatPrice = (amount: number) => {
    return new Intl.NumberFormat("vi-VN", {
      style: "currency",
      currency: "VND",
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(amount)
  }

  return (
    <Link href={`/san-pham/${product.id}`}>
      <div className="bg-white rounded-lg overflow-hidden shadow-sm hover:shadow-md transition-shadow duration-200">
        <div className="relative aspect-square">
          {/* Hình ảnh sản phẩm */}
          <div className={`absolute inset-0 bg-gray-100 ${isLoading ? "animate-pulse" : ""}`}></div>
          <Image
            src={product.image || "/placeholder.svg"}
            alt={product.name}
            fill
            className={`object-cover transition-opacity duration-300 ${isLoading ? "opacity-0" : "opacity-100"}`}
            onLoad={() => setIsLoading(false)}
          />

          {/* Badge giảm giá */}
          {product.discount && product.discount > 0 && (
            <div className="absolute top-2 left-2 bg-rose-500 text-white text-xs font-medium px-1.5 py-0.5 rounded">
              -{product.discount}%
            </div>
          )}

          {/* Badge sản phẩm mới */}
          {product.isNew && (
            <div className="absolute top-2 right-2 bg-blue-500 text-white text-xs font-medium px-1.5 py-0.5 rounded">
              Mới
            </div>
          )}

          {/* Nút yêu thích */}
          <button
            onClick={toggleFavorite}
            className="absolute bottom-2 right-2 bg-white rounded-full p-1.5 shadow-md hover:bg-gray-100 transition"
            aria-label={isFavorite ? "Bỏ yêu thích" : "Yêu thích"}
          >
            <Heart className={`w-4 h-4 ${isFavorite ? "fill-rose-500 text-rose-500" : "text-gray-600"}`} />
          </button>
        </div>

        <div className="p-2">
          {/* Tên sản phẩm */}
          <h3 className="text-sm font-medium line-clamp-2 min-h-[2.5rem]">{product.name}</h3>

          {/* Giá */}
          <div className="mt-1 flex items-center">
            {product.salePrice && product.salePrice < product.price ? (
              <>
                <span className="text-rose-500 font-medium">{formatPrice(product.salePrice)}</span>
                <span className="ml-1 text-xs text-gray-500 line-through">{formatPrice(product.price)}</span>
              </>
            ) : (
              <span className="font-medium">{formatPrice(product.price)}</span>
            )}
          </div>

          {/* Nút thêm vào giỏ hàng */}
          <button
            onClick={handleAddToCart}
            className="mt-2 w-full bg-black text-white rounded-full py-1.5 text-xs font-medium flex items-center justify-center hover:bg-gray-800 transition"
          >
            <ShoppingBag className="w-3 h-3 mr-1" />
            Thêm vào giỏ
          </button>
        </div>
      </div>
    </Link>
  )
}
