"use client"

import { useEffect, useState } from "react"
import Link from "next/link"
import { ProductCard } from "@/components/product-card"
import { Button } from "@/components/ui/button"
import { LoadingIndicator } from "@/components/loading-indicator"

// Mock data - Thay thế bằng dữ liệu thực từ API
const mockProducts = [
  {
    id: "2",
    name: "Áo Sơ Mi Nam Dài Tay",
    price: 299000,
    salePrice: 249000,
    image: "/placeholder.svg?height=300&width=300",
    rating: 4.3,
    reviewCount: 56,
    isNew: true,
    discount: 17,
  },
  {
    id: "3",
    name: "Áo Polo Nam Cotton",
    price: 249000,
    salePrice: 199000,
    image: "/placeholder.svg?height=300&width=300",
    rating: 4.7,
    reviewCount: 89,
    isNew: false,
    discount: 20,
  },
  {
    id: "4",
    name: "Áo Khoác Denim Unisex",
    price: 499000,
    salePrice: 399000,
    image: "/placeholder.svg?height=300&width=300",
    rating: 4.8,
    reviewCount: 112,
    isNew: true,
    discount: 20,
  },
  {
    id: "5",
    name: "Áo Thun Nữ Form Rộng",
    price: 189000,
    salePrice: 159000,
    image: "/placeholder.svg?height=300&width=300",
    rating: 4.5,
    reviewCount: 78,
    isNew: false,
    discount: 16,
  },
]

interface ProductSuggestionsProps {
  productId: string
  category?: string
  limit?: number
}

export function ProductSuggestions({ productId, category, limit = 4 }: ProductSuggestionsProps) {
  const [products, setProducts] = useState<any[]>([])
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    // Giả lập fetch dữ liệu
    const fetchProducts = async () => {
      setIsLoading(true)
      // Trong thực tế, gọi API để lấy sản phẩm tương tự
      await new Promise((resolve) => setTimeout(resolve, 800))

      // Lọc ra sản phẩm hiện tại
      const filteredProducts = mockProducts.filter((p) => p.id !== productId)
      setProducts(filteredProducts.slice(0, limit))
      setIsLoading(false)
    }

    fetchProducts()
  }, [productId, category, limit])

  if (isLoading) {
    return <LoadingIndicator />
  }

  if (products.length === 0) {
    return <div className="text-center py-8 text-gray-500">Không tìm thấy sản phẩm tương tự</div>
  }

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-2 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
        {products.map((product) => (
          <ProductCard key={product.id} product={product} />
        ))}
      </div>

      <div className="flex justify-center mt-6">
        <Button variant="outline" asChild>
          <Link href={`/danh-muc/${category?.toLowerCase() || "tat-ca"}`}>Xem thêm sản phẩm tương tự</Link>
        </Button>
      </div>
    </div>
  )
}
