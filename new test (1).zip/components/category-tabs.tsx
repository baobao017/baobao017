"use client"

import { useState } from "react"
import Link from "next/link"
import Image from "next/image"
import { cn } from "@/lib/utils"

const categories = [
  {
    id: "all",
    name: "Tất cả",
    icon: "/placeholder.svg?height=40&width=40",
    href: "/danh-muc/tat-ca",
  },
  {
    id: "new",
    name: "Hàng mới",
    icon: "/placeholder.svg?height=40&width=40",
    href: "/danh-muc/hang-moi-ve",
  },
  {
    id: "hot",
    name: "Hot trend",
    icon: "/placeholder.svg?height=40&width=40",
    href: "/danh-muc/hot-trend",
  },
  {
    id: "sale",
    name: "Giảm giá",
    icon: "/placeholder.svg?height=40&width=40",
    href: "/danh-muc/giam-gia",
  },
  {
    id: "under100k",
    name: "Dưới 100K",
    icon: "/placeholder.svg?height=40&width=40",
    href: "/danh-muc/deal-duoi-100k",
  },
]

export default function CategoryTabs() {
  const [activeCategory, setActiveCategory] = useState("all")

  return (
    <div className="overflow-x-auto scrollbar-hide py-4">
      <div className="flex space-x-4 px-4 min-w-max">
        {categories.map((category) => (
          <Link
            key={category.id}
            href={category.href}
            className="flex flex-col items-center"
            onClick={() => setActiveCategory(category.id)}
          >
            <div
              className={cn(
                "w-16 h-16 rounded-full flex items-center justify-center mb-1",
                activeCategory === category.id ? "bg-primary/10 border-2 border-primary" : "bg-gray-100",
              )}
            >
              <div className="relative w-8 h-8">
                <Image src={category.icon || "/placeholder.svg"} alt={category.name} fill className="object-contain" />
              </div>
            </div>
            <span className="text-xs font-medium">{category.name}</span>
          </Link>
        ))}
      </div>
    </div>
  )
}
