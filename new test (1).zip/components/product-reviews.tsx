"use client"

import type React from "react"

import { useState } from "react"
import { Star, ThumbsUp, MessageSquare } from "lucide-react"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { Progress } from "@/components/ui/progress"
import { cn } from "@/lib/utils"

// Mock data - Thay thế bằng dữ liệu thực từ API
const reviews = [
  {
    id: "1",
    user: {
      name: "Nguyễn Văn A",
      avatar: "/placeholder.svg?height=40&width=40",
    },
    rating: 5,
    date: "2023-05-15",
    content:
      "Sản phẩm rất tốt, chất lượng vải đẹp, form chuẩn. Đóng gói cẩn thận, giao hàng nhanh. Sẽ ủng hộ shop dài dài.",
    likes: 12,
    replies: 2,
    images: ["/placeholder.svg?height=100&width=100", "/placeholder.svg?height=100&width=100"],
  },
  {
    id: "2",
    user: {
      name: "Trần Thị B",
      avatar: "/placeholder.svg?height=40&width=40",
    },
    rating: 4,
    date: "2023-05-10",
    content: "Áo đẹp, đúng như mô tả. Chỉ tiếc là màu hơi sáng hơn trong ảnh một chút. Nhưng nhìn chung là ưng ý.",
    likes: 5,
    replies: 1,
    images: [],
  },
  {
    id: "3",
    user: {
      name: "Lê Văn C",
      avatar: "/placeholder.svg?height=40&width=40",
    },
    rating: 3,
    date: "2023-05-05",
    content: "Sản phẩm tạm ổn, vải hơi mỏng. Giao hàng nhanh.",
    likes: 2,
    replies: 0,
    images: [],
  },
]

// Thống kê đánh giá
const ratingStats = {
  average: 4.5,
  total: 120,
  distribution: [
    { rating: 5, count: 80 },
    { rating: 4, count: 25 },
    { rating: 3, count: 10 },
    { rating: 2, count: 3 },
    { rating: 1, count: 2 },
  ],
}

interface ProductReviewsProps {
  productId: string
}

export function ProductReviews({ productId }: ProductReviewsProps) {
  const [reviewContent, setReviewContent] = useState("")
  const [userRating, setUserRating] = useState(0)
  const [hoveredRating, setHoveredRating] = useState(0)

  const handleSubmitReview = (e: React.FormEvent) => {
    e.preventDefault()
    // Xử lý gửi đánh giá
    console.log({ rating: userRating, content: reviewContent })
    setReviewContent("")
    setUserRating(0)
  }

  return (
    <div className="space-y-6">
      {/* Thống kê đánh giá */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 p-4 bg-gray-50 rounded-lg">
        <div className="flex flex-col items-center justify-center space-y-2">
          <div className="text-4xl font-bold">{ratingStats.average.toFixed(1)}</div>
          <div className="flex">
            {Array(5)
              .fill(0)
              .map((_, i) => (
                <Star
                  key={i}
                  className={cn(
                    "h-5 w-5",
                    i < Math.floor(ratingStats.average)
                      ? "text-yellow-400 fill-yellow-400"
                      : i < ratingStats.average
                        ? "text-yellow-400 fill-yellow-400"
                        : "text-gray-300",
                  )}
                />
              ))}
          </div>
          <div className="text-sm text-gray-500">{ratingStats.total} đánh giá</div>
        </div>

        <div className="space-y-2">
          {ratingStats.distribution.map((item) => (
            <div key={item.rating} className="flex items-center gap-2">
              <div className="flex items-center w-12">
                <span>{item.rating}</span>
                <Star className="h-4 w-4 ml-1 text-yellow-400 fill-yellow-400" />
              </div>
              <Progress value={(item.count / ratingStats.total) * 100} className="h-2 flex-1" />
              <div className="w-12 text-right text-sm text-gray-500">
                {Math.round((item.count / ratingStats.total) * 100)}%
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Form đánh giá */}
      <div className="border rounded-lg p-4">
        <h3 className="text-lg font-medium mb-4">Viết đánh giá của bạn</h3>
        <form onSubmit={handleSubmitReview} className="space-y-4">
          <div className="flex items-center space-x-1">
            {Array(5)
              .fill(0)
              .map((_, i) => (
                <button
                  key={i}
                  type="button"
                  className="focus:outline-none"
                  onMouseEnter={() => setHoveredRating(i + 1)}
                  onMouseLeave={() => setHoveredRating(0)}
                  onClick={() => setUserRating(i + 1)}
                >
                  <Star
                    className={cn(
                      "h-6 w-6 transition-colors",
                      (hoveredRating > 0 ? i < hoveredRating : i < userRating)
                        ? "text-yellow-400 fill-yellow-400"
                        : "text-gray-300",
                    )}
                  />
                </button>
              ))}
            <span className="ml-2 text-sm text-gray-500">
              {userRating > 0 ? `Bạn đã chọn ${userRating} sao` : "Chọn đánh giá của bạn"}
            </span>
          </div>

          <Textarea
            placeholder="Chia sẻ trải nghiệm của bạn về sản phẩm này..."
            value={reviewContent}
            onChange={(e) => setReviewContent(e.target.value)}
            rows={4}
          />

          <Button type="submit" disabled={userRating === 0 || !reviewContent.trim()}>
            Gửi đánh giá
          </Button>
        </form>
      </div>

      {/* Danh sách đánh giá */}
      <div className="space-y-4">
        {reviews.map((review) => (
          <div key={review.id} className="border rounded-lg p-4">
            <div className="flex justify-between">
              <div className="flex items-center space-x-2">
                <Avatar>
                  <AvatarImage src={review.user.avatar || "/placeholder.svg"} alt={review.user.name} />
                  <AvatarFallback>{review.user.name.charAt(0)}</AvatarFallback>
                </Avatar>
                <div>
                  <div className="font-medium">{review.user.name}</div>
                  <div className="flex items-center">
                    {Array(5)
                      .fill(0)
                      .map((_, i) => (
                        <Star
                          key={i}
                          className={cn(
                            "h-4 w-4",
                            i < review.rating ? "text-yellow-400 fill-yellow-400" : "text-gray-300",
                          )}
                        />
                      ))}
                  </div>
                </div>
              </div>
              <div className="text-sm text-gray-500">{new Date(review.date).toLocaleDateString("vi-VN")}</div>
            </div>

            <div className="mt-3">{review.content}</div>

            {review.images.length > 0 && (
              <div className="flex mt-3 space-x-2">
                {review.images.map((image, index) => (
                  <div key={index} className="relative h-20 w-20 overflow-hidden rounded-md">
                    <img
                      src={image || "/placeholder.svg"}
                      alt={`Review image ${index + 1}`}
                      className="object-cover h-full w-full"
                    />
                  </div>
                ))}
              </div>
            )}

            <div className="flex items-center mt-3 space-x-4">
              <button className="flex items-center text-sm text-gray-500 hover:text-gray-700">
                <ThumbsUp className="h-4 w-4 mr-1" />
                <span>Hữu ích ({review.likes})</span>
              </button>
              <button className="flex items-center text-sm text-gray-500 hover:text-gray-700">
                <MessageSquare className="h-4 w-4 mr-1" />
                <span>Trả lời ({review.replies})</span>
              </button>
            </div>
          </div>
        ))}
      </div>

      <Button variant="outline" className="w-full">
        Xem thêm đánh giá
      </Button>
    </div>
  )
}
