import { Loader2 } from "lucide-react"

interface LoadingIndicatorProps {
  size?: "sm" | "md" | "lg"
  text?: string
}

export function LoadingIndicator({ size = "md", text = "Đang tải..." }: LoadingIndicatorProps) {
  const sizeMap = {
    sm: "h-4 w-4",
    md: "h-8 w-8",
    lg: "h-12 w-12",
  }

  return (
    <div className="flex flex-col items-center justify-center py-8">
      <Loader2 className={`${sizeMap[size]} animate-spin text-primary`} />
      {text && <p className="mt-2 text-sm text-gray-500">{text}</p>}
    </div>
  )
}
