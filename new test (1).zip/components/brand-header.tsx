"use client"

import { useState } from "react"
import Image from "next/image"
import Link from "next/link"
import { ChevronLeft, ChevronRight } from "lucide-react"

const banners = [
  {
    id: 1,
    image: "/placeholder.svg?height=400&width=800",
    alt: "Bộ sưu tập mùa hè",
    link: "/bo-suu-tap/ao",
    title: "Bộ sưu tập mùa hè",
    subtitle: "Giảm đến 50%",
  },
  {
    id: 2,
    image: "/placeholder.svg?height=400&width=800",
    alt: "Váy đầm mới về",
    link: "/bo-suu-tap/vay-dam",
    title: "Váy đầm mới về",
    subtitle: "Mua 2 tặng 1",
  },
  {
    id: 3,
    image: "/placeholder.svg?height=400&width=800",
    alt: "Đồ bộ thoải mái",
    link: "/bo-suu-tap/do-bo",
    title: "Đồ bộ thoải mái",
    subtitle: "Từ 99.000đ",
  },
]

export default function BrandHeader() {
  const [currentBanner, setCurrentBanner] = useState(0)

  const nextBanner = () => {
    setCurrentBanner((prev) => (prev + 1) % banners.length)
  }

  const prevBanner = () => {
    setCurrentBanner((prev) => (prev - 1 + banners.length) % banners.length)
  }

  return (
    <div className="relative h-[200px] md:h-[300px] overflow-hidden mx-4 my-4 rounded-lg">
      {/* Banner */}
      <div className="relative h-full w-full">
        {banners.map((banner, index) => (
          <div
            key={banner.id}
            className={`absolute inset-0 transition-opacity duration-500 ${
              index === currentBanner ? "opacity-100" : "opacity-0 pointer-events-none"
            }`}
          >
            <Link href={banner.link}>
              <div className="relative h-full w-full">
                <Image
                  src={banner.image || "/placeholder.svg"}
                  alt={banner.alt}
                  fill
                  className="object-cover"
                  priority={index === 0}
                />
                <div className="absolute inset-0 bg-gradient-to-r from-black/50 to-transparent flex flex-col justify-center px-6">
                  <h2 className="text-white text-2xl md:text-3xl font-bold">{banner.title}</h2>
                  <p className="text-white text-lg md:text-xl mt-2">{banner.subtitle}</p>
                  <button className="bg-white text-black px-4 py-2 rounded-full mt-4 w-max text-sm font-medium hover:bg-gray-100 transition">
                    Mua ngay
                  </button>
                </div>
              </div>
            </Link>
          </div>
        ))}
      </div>

      {/* Nút điều hướng */}
      <button
        onClick={prevBanner}
        className="absolute left-2 top-1/2 -translate-y-1/2 bg-white/80 rounded-full p-1 hover:bg-white transition"
        aria-label="Banner trước"
      >
        <ChevronLeft className="w-5 h-5" />
      </button>
      <button
        onClick={nextBanner}
        className="absolute right-2 top-1/2 -translate-y-1/2 bg-white/80 rounded-full p-1 hover:bg-white transition"
        aria-label="Banner tiếp theo"
      >
        <ChevronRight className="w-5 h-5" />
      </button>

      {/* Chỉ số banner */}
      <div className="absolute bottom-3 left-1/2 -translate-x-1/2 flex space-x-2">
        {banners.map((_, index) => (
          <button
            key={index}
            onClick={() => setCurrentBanner(index)}
            className={`w-2 h-2 rounded-full transition-all ${
              index === currentBanner ? "bg-white w-4" : "bg-white/50"
            }`}
            aria-label={`Chuyển đến banner ${index + 1}`}
          />
        ))}
      </div>
    </div>
  )
}
