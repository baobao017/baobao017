interface ProductSpecificationsProps {
  specifications: Record<string, string>
}

export function ProductSpecifications({ specifications }: ProductSpecificationsProps) {
  return (
    <div className="overflow-hidden rounded-md border">
      <table className="w-full text-sm">
        <tbody>
          {Object.entries(specifications).map(([key, value], index) => (
            <tr key={key} className={index % 2 === 0 ? "bg-gray-50" : "bg-white"}>
              <th className="px-4 py-3 text-left font-medium text-gray-700">{key}</th>
              <td className="px-4 py-3 text-gray-700">{value}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  )
}
