"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import Image from "next/image"
import { ShoppingCart, Trash2, ChevronLeft, ChevronRight, Plus, Minus, RefreshCw, ShoppingBag } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Separator } from "@/components/ui/separator"
import { LoadingIndicator } from "@/components/loading-indicator"
import { ProductSuggestions } from "@/components/product-suggestions"

// Mock data - Thay thế bằng dữ liệu thực từ API
const cartItems = [
  {
    id: "1",
    productId: "101",
    name: "Áo Thun Unisex Cotton Form Rộng",
    price: 199000,
    salePrice: 149000,
    image: "/placeholder.svg?height=120&width=120",
    color: "Đen",
    size: "L",
    quantity: 2,
    stock: 10,
  },
  {
    id: "2",
    productId: "102",
    name: "Quần Jean Nam Slim Fit",
    price: 399000,
    salePrice: 399000,
    image: "/placeholder.svg?height=120&width=120",
    color: "Xanh đậm",
    size: "32",
    quantity: 1,
    stock: 5,
  },
]

export default function CartPage() {
  const [items, setItems] = useState(cartItems)
  const [isLoading, setIsLoading] = useState(true)
  const [couponCode, setCouponCode] = useState("")
  const [isApplyingCoupon, setIsApplyingCoupon] = useState(false)

  useEffect(() => {
    // Giả lập fetch dữ liệu
    const fetchCart = async () => {
      await new Promise((resolve) => setTimeout(resolve, 800))
      setIsLoading(false)
    }

    fetchCart()
  }, [])

  const updateQuantity = (id: string, newQuantity: number) => {
    if (newQuantity < 1) return

    setItems(items.map((item) => (item.id === id ? { ...item, quantity: Math.min(newQuantity, item.stock) } : item)))
  }

  const removeItem = (id: string) => {
    setItems(items.filter((item) => item.id !== id))
  }

  const applyCoupon = async () => {
    if (!couponCode.trim()) return

    setIsApplyingCoupon(true)
    // Giả lập API call
    await new Promise((resolve) => setTimeout(resolve, 1000))
    setIsApplyingCoupon(false)

    // Giả sử mã không hợp lệ
    alert("Mã giảm giá không hợp lệ hoặc đã hết hạn")
  }

  // Tính toán
  const subtotal = items.reduce((sum, item) => sum + item.salePrice * item.quantity, 0)
  const shipping = subtotal > 300000 ? 0 : 30000
  const discount = 0 // Từ mã giảm giá
  const total = subtotal + shipping - discount

  if (isLoading) {
    return (
      <div className="container mx-auto px-4 py-8">
        <LoadingIndicator text="Đang tải giỏ hàng..." />
      </div>
    )
  }

  if (items.length === 0) {
    return (
      <div className="container mx-auto px-4 py-8">
        <div className="flex flex-col items-center justify-center py-12 text-center">
          <div className="bg-gray-100 p-6 rounded-full mb-4">
            <ShoppingCart className="h-12 w-12 text-gray-400" />
          </div>
          <h2 className="text-2xl font-bold mb-2">Giỏ hàng trống</h2>
          <p className="text-gray-500 mb-6">Bạn chưa có sản phẩm nào trong giỏ hàng</p>
          <Button asChild>
            <Link href="/danh-muc/tat-ca">
              <ShoppingBag className="mr-2 h-4 w-4" />
              Tiếp tục mua sắm
            </Link>
          </Button>

          <div className="mt-12 w-full">
            <h3 className="text-xl font-bold mb-4">Có thể bạn sẽ thích</h3>
            <ProductSuggestions productId="" limit={4} />
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-2xl font-bold mb-6 flex items-center">
        <ShoppingCart className="mr-2 h-6 w-6" />
        Giỏ hàng của bạn ({items.length} sản phẩm)
      </h1>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2">
          <div className="bg-white rounded-lg shadow-sm border overflow-hidden">
            <div className="p-4 bg-gray-50 border-b">
              <div className="grid grid-cols-12 gap-4 text-sm font-medium text-gray-500">
                <div className="col-span-6">Sản phẩm</div>
                <div className="col-span-2 text-center">Đơn giá</div>
                <div className="col-span-2 text-center">Số lượng</div>
                <div className="col-span-2 text-right">Thành tiền</div>
              </div>
            </div>

            <div className="divide-y">
              {items.map((item) => (
                <div key={item.id} className="p-4">
                  <div className="grid grid-cols-12 gap-4 items-center">
                    <div className="col-span-6">
                      <div className="flex items-center space-x-4">
                        <div className="relative h-20 w-20 rounded-md overflow-hidden flex-shrink-0">
                          <Image src={item.image || "/placeholder.svg"} alt={item.name} fill className="object-cover" />
                        </div>
                        <div>
                          <h3 className="font-medium text-gray-900">
                            <Link href={`/san-pham/${item.productId}`} className="hover:text-primary">
                              {item.name}
                            </Link>
                          </h3>
                          <div className="text-sm text-gray-500 mt-1">
                            <span>Màu: {item.color}</span>
                            <span className="mx-2">|</span>
                            <span>Size: {item.size}</span>
                          </div>
                          <button
                            onClick={() => removeItem(item.id)}
                            className="text-red-500 hover:text-red-700 text-sm flex items-center mt-2"
                          >
                            <Trash2 className="h-3.5 w-3.5 mr-1" />
                            Xóa
                          </button>
                        </div>
                      </div>
                    </div>

                    <div className="col-span-2 text-center">
                      {item.salePrice < item.price ? (
                        <div>
                          <div className="font-medium">
                            {new Intl.NumberFormat("vi-VN", { style: "currency", currency: "VND" }).format(
                              item.salePrice,
                            )}
                          </div>
                          <div className="text-sm text-gray-500 line-through">
                            {new Intl.NumberFormat("vi-VN", { style: "currency", currency: "VND" }).format(item.price)}
                          </div>
                        </div>
                      ) : (
                        <div className="font-medium">
                          {new Intl.NumberFormat("vi-VN", { style: "currency", currency: "VND" }).format(item.price)}
                        </div>
                      )}
                    </div>

                    <div className="col-span-2 flex justify-center">
                      <div className="flex items-center border rounded-md">
                        <button
                          className="px-2 py-1 text-gray-600 hover:text-gray-800 disabled:opacity-50"
                          onClick={() => updateQuantity(item.id, item.quantity - 1)}
                          disabled={item.quantity <= 1}
                        >
                          <Minus className="h-4 w-4" />
                        </button>
                        <input
                          type="number"
                          min="1"
                          max={item.stock}
                          value={item.quantity}
                          onChange={(e) => updateQuantity(item.id, Number.parseInt(e.target.value) || 1)}
                          className="w-12 text-center border-x py-1 [appearance:textfield] [&::-webkit-inner-spin-button]:appearance-none [&::-webkit-outer-spin-button]:appearance-none"
                        />
                        <button
                          className="px-2 py-1 text-gray-600 hover:text-gray-800 disabled:opacity-50"
                          onClick={() => updateQuantity(item.id, item.quantity + 1)}
                          disabled={item.quantity >= item.stock}
                        >
                          <Plus className="h-4 w-4" />
                        </button>
                      </div>
                    </div>

                    <div className="col-span-2 text-right font-medium">
                      {new Intl.NumberFormat("vi-VN", { style: "currency", currency: "VND" }).format(
                        item.salePrice * item.quantity,
                      )}
                    </div>
                  </div>
                </div>
              ))}
            </div>

            <div className="p-4 bg-gray-50 border-t flex justify-between items-center">
              <Button variant="outline" size="sm" asChild>
                <Link href="/danh-muc/tat-ca">
                  <ChevronLeft className="mr-1 h-4 w-4" />
                  Tiếp tục mua sắm
                </Link>
              </Button>

              <Button size="sm" variant="ghost" onClick={() => window.location.reload()}>
                <RefreshCw className="mr-1 h-4 w-4" />
                Cập nhật giỏ hàng
              </Button>
            </div>
          </div>
        </div>

        <div className="lg:col-span-1">
          <div className="bg-white rounded-lg shadow-sm border p-4 sticky top-4">
            <h2 className="text-lg font-bold mb-4">Tóm tắt đơn hàng</h2>

            <div className="space-y-3 text-sm">
              <div className="flex justify-between">
                <span className="text-gray-600">
                  Tạm tính ({items.reduce((sum, item) => sum + item.quantity, 0)} sản phẩm):
                </span>
                <span className="font-medium">
                  {new Intl.NumberFormat("vi-VN", { style: "currency", currency: "VND" }).format(subtotal)}
                </span>
              </div>

              <div className="flex justify-between">
                <span className="text-gray-600">Phí vận chuyển:</span>
                <span className="font-medium">
                  {shipping === 0
                    ? "Miễn phí"
                    : new Intl.NumberFormat("vi-VN", { style: "currency", currency: "VND" }).format(shipping)}
                </span>
              </div>

              {discount > 0 && (
                <div className="flex justify-between text-green-600">
                  <span>Giảm giá:</span>
                  <span className="font-medium">
                    -{new Intl.NumberFormat("vi-VN", { style: "currency", currency: "VND" }).format(discount)}
                  </span>
                </div>
              )}

              <Separator />

              <div className="flex justify-between text-base font-bold">
                <span>Tổng cộng:</span>
                <span className="text-primary">
                  {new Intl.NumberFormat("vi-VN", { style: "currency", currency: "VND" }).format(total)}
                </span>
              </div>
            </div>

            <div className="mt-6 space-y-4">
              <div className="flex space-x-2">
                <Input
                  placeholder="Nhập mã giảm giá"
                  value={couponCode}
                  onChange={(e) => setCouponCode(e.target.value)}
                />
                <Button variant="outline" onClick={applyCoupon} disabled={isApplyingCoupon || !couponCode.trim()}>
                  {isApplyingCoupon ? "Đang áp dụng..." : "Áp dụng"}
                </Button>
              </div>

              <Button className="w-full" asChild>
                <Link href="/thanh-toan">
                  Tiến hành thanh toán
                  <ChevronRight className="ml-1 h-4 w-4" />
                </Link>
              </Button>
            </div>

            <div className="mt-4 text-xs text-gray-500">
              <p>
                Bằng cách tiến hành thanh toán, bạn đồng ý với{" "}
                <Link href="/dieu-khoan" className="text-primary hover:underline">
                  Điều khoản dịch vụ
                </Link>{" "}
                và{" "}
                <Link href="/chinh-sach" className="text-primary hover:underline">
                  Chính sách bảo mật
                </Link>{" "}
                của chúng tôi.
              </p>
            </div>
          </div>
        </div>
      </div>

      <div className="mt-12">
        <h2 className="text-xl font-bold mb-4">Có thể bạn cũng thích</h2>
        <ProductSuggestions productId="" limit={4} />
      </div>
    </div>
  )
}
