"use client"

import type React from "react"

import { useState, useEffect } from "react"
import Link from "next/link"
import Image from "next/image"
import {
  CreditCard,
  Truck,
  ChevronLeft,
  ChevronRight,
  CheckCircle2,
  MapPin,
  Phone,
  User,
  Mail,
  FileText,
  ShoppingBag,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Separator } from "@/components/ui/separator"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Label } from "@/components/ui/label"
import { Checkbox } from "@/components/ui/checkbox"
import { LoadingIndicator } from "@/components/loading-indicator"
import { OrderSuccessDialog } from "@/components/order-success-dialog"

// Mock data - Thay thế bằng dữ liệu thực từ API
const cartItems = [
  {
    id: "1",
    name: "Áo Thun Unisex Cotton Form Rộng",
    price: 199000,
    salePrice: 149000,
    image: "/placeholder.svg?height=80&width=80",
    color: "Đen",
    size: "L",
    quantity: 2,
  },
  {
    id: "2",
    name: "Quần Jean Nam Slim Fit",
    price: 399000,
    salePrice: 399000,
    image: "/placeholder.svg?height=80&width=80",
    color: "Xanh đậm",
    size: "32",
    quantity: 1,
  },
]

const paymentMethods = [
  {
    id: "cod",
    name: "Thanh toán khi nhận hàng (COD)",
    description: "Thanh toán bằng tiền mặt khi nhận hàng",
    icon: "/placeholder.svg?height=40&width=40",
  },
  {
    id: "banking",
    name: "Chuyển khoản ngân hàng",
    description: "Chuyển khoản qua tài khoản ngân hàng",
    icon: "/placeholder.svg?height=40&width=40",
  },
  {
    id: "momo",
    name: "Ví MoMo",
    description: "Thanh toán qua ví điện tử MoMo",
    icon: "/placeholder.svg?height=40&width=40",
  },
  {
    id: "zalopay",
    name: "ZaloPay",
    description: "Thanh toán qua ví điện tử ZaloPay",
    icon: "/placeholder.svg?height=40&width=40",
  },
]

const shippingMethods = [
  {
    id: "standard",
    name: "Giao hàng tiêu chuẩn",
    price: 30000,
    description: "Nhận hàng trong 3-5 ngày",
    icon: "/placeholder.svg?height=40&width=40",
  },
  {
    id: "express",
    name: "Giao hàng nhanh",
    price: 50000,
    description: "Nhận hàng trong 1-2 ngày",
    icon: "/placeholder.svg?height=40&width=40",
  },
]

export default function CheckoutPage() {
  const [isLoading, setIsLoading] = useState(true)
  const [showSuccessDialog, setShowSuccessDialog] = useState(false)
  const [isSubmitting, setIsSubmitting] = useState(false)

  const [formData, setFormData] = useState({
    fullName: "",
    phone: "",
    email: "",
    address: "",
    province: "",
    district: "",
    ward: "",
    note: "",
    paymentMethod: "cod",
    shippingMethod: "standard",
    saveInfo: true,
    createAccount: false,
  })

  useEffect(() => {
    // Giả lập fetch dữ liệu
    const fetchData = async () => {
      await new Promise((resolve) => setTimeout(resolve, 800))
      setIsLoading(false)
    }

    fetchData()
  }, [])

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target
    setFormData((prev) => ({ ...prev, [name]: value }))
  }

  const handleCheckboxChange = (name: string, checked: boolean) => {
    setFormData((prev) => ({ ...prev, [name]: checked }))
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsSubmitting(true)

    // Giả lập gửi đơn hàng
    await new Promise((resolve) => setTimeout(resolve, 1500))

    setIsSubmitting(false)
    setShowSuccessDialog(true)
  }

  // Tính toán
  const subtotal = cartItems.reduce((sum, item) => sum + item.salePrice * item.quantity, 0)
  const selectedShipping = shippingMethods.find((m) => m.id === formData.shippingMethod)
  const shipping = selectedShipping?.price || 0
  const discount = 0 // Từ mã giảm giá
  const total = subtotal + shipping - discount

  if (isLoading) {
    return (
      <div className="container mx-auto px-4 py-8">
        <LoadingIndicator text="Đang tải thông tin thanh toán..." />
      </div>
    )
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-2xl font-bold mb-6 flex items-center">
        <CreditCard className="mr-2 h-6 w-6" />
        Thanh toán
      </h1>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2">
          <form onSubmit={handleSubmit}>
            <div className="bg-white rounded-lg shadow-sm border overflow-hidden mb-6">
              <div className="p-4 bg-gray-50 border-b flex items-center">
                <MapPin className="h-5 w-5 text-primary mr-2" />
                <h2 className="text-lg font-bold">Thông tin giao hàng</h2>
              </div>

              <div className="p-6 grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="md:col-span-2 flex items-center space-x-2">
                  <User className="h-4 w-4 text-gray-500" />
                  <Input
                    name="fullName"
                    placeholder="Họ và tên người nhận *"
                    value={formData.fullName}
                    onChange={handleInputChange}
                    required
                  />
                </div>

                <div className="flex items-center space-x-2">
                  <Phone className="h-4 w-4 text-gray-500" />
                  <Input
                    name="phone"
                    placeholder="Số điện thoại *"
                    value={formData.phone}
                    onChange={handleInputChange}
                    required
                  />
                </div>

                <div className="flex items-center space-x-2">
                  <Mail className="h-4 w-4 text-gray-500" />
                  <Input
                    name="email"
                    type="email"
                    placeholder="Email"
                    value={formData.email}
                    onChange={handleInputChange}
                  />
                </div>

                <div className="md:col-span-2 flex items-center space-x-2">
                  <MapPin className="h-4 w-4 text-gray-500" />
                  <Input
                    name="address"
                    placeholder="Địa chỉ cụ thể *"
                    value={formData.address}
                    onChange={handleInputChange}
                    required
                  />
                </div>

                <div>
                  <Input
                    name="province"
                    placeholder="Tỉnh/Thành phố *"
                    value={formData.province}
                    onChange={handleInputChange}
                    required
                  />
                </div>

                <div>
                  <Input
                    name="district"
                    placeholder="Quận/Huyện *"
                    value={formData.district}
                    onChange={handleInputChange}
                    required
                  />
                </div>

                <div>
                  <Input
                    name="ward"
                    placeholder="Phường/Xã *"
                    value={formData.ward}
                    onChange={handleInputChange}
                    required
                  />
                </div>

                <div className="md:col-span-2 flex items-center space-x-2">
                  <FileText className="h-4 w-4 text-gray-500" />
                  <Textarea
                    name="note"
                    placeholder="Ghi chú đơn hàng (không bắt buộc)"
                    value={formData.note}
                    onChange={handleInputChange}
                    className="min-h-[80px]"
                  />
                </div>

                <div className="md:col-span-2 space-y-2">
                  <div className="flex items-center space-x-2">
                    <Checkbox
                      id="saveInfo"
                      checked={formData.saveInfo}
                      onCheckedChange={(checked) => handleCheckboxChange("saveInfo", checked as boolean)}
                    />
                    <Label htmlFor="saveInfo">Lưu thông tin cho lần mua hàng sau</Label>
                  </div>

                  <div className="flex items-center space-x-2">
                    <Checkbox
                      id="createAccount"
                      checked={formData.createAccount}
                      onCheckedChange={(checked) => handleCheckboxChange("createAccount", checked as boolean)}
                    />
                    <Label htmlFor="createAccount">Tạo tài khoản mới</Label>
                  </div>
                </div>
              </div>
            </div>

            <div className="bg-white rounded-lg shadow-sm border overflow-hidden mb-6">
              <div className="p-4 bg-gray-50 border-b flex items-center">
                <Truck className="h-5 w-5 text-primary mr-2" />
                <h2 className="text-lg font-bold">Phương thức vận chuyển</h2>
              </div>

              <div className="p-6">
                <RadioGroup
                  value={formData.shippingMethod}
                  onValueChange={(value) => setFormData((prev) => ({ ...prev, shippingMethod: value }))}
                  className="space-y-3"
                >
                  {shippingMethods.map((method) => (
                    <div key={method.id} className="flex items-center space-x-3 rounded-lg border p-4">
                      <RadioGroupItem value={method.id} id={`shipping-${method.id}`} />
                      <Label htmlFor={`shipping-${method.id}`} className="flex-1 flex items-center cursor-pointer">
                        <div className="relative h-10 w-10 mr-3">
                          <Image
                            src={method.icon || "/placeholder.svg"}
                            alt={method.name}
                            fill
                            className="object-contain"
                          />
                        </div>
                        <div className="flex-1">
                          <div className="font-medium">{method.name}</div>
                          <div className="text-sm text-gray-500">{method.description}</div>
                        </div>
                        <div className="font-medium">
                          {method.price === 0
                            ? "Miễn phí"
                            : new Intl.NumberFormat("vi-VN", { style: "currency", currency: "VND" }).format(
                                method.price,
                              )}
                        </div>
                      </Label>
                    </div>
                  ))}
                </RadioGroup>
              </div>
            </div>

            <div className="bg-white rounded-lg shadow-sm border overflow-hidden mb-6">
              <div className="p-4 bg-gray-50 border-b flex items-center">
                <CreditCard className="h-5 w-5 text-primary mr-2" />
                <h2 className="text-lg font-bold">Phương thức thanh toán</h2>
              </div>

              <div className="p-6">
                <RadioGroup
                  value={formData.paymentMethod}
                  onValueChange={(value) => setFormData((prev) => ({ ...prev, paymentMethod: value }))}
                  className="space-y-3"
                >
                  {paymentMethods.map((method) => (
                    <div key={method.id} className="flex items-center space-x-3 rounded-lg border p-4">
                      <RadioGroupItem value={method.id} id={`payment-${method.id}`} />
                      <Label htmlFor={`payment-${method.id}`} className="flex-1 flex items-center cursor-pointer">
                        <div className="relative h-10 w-10 mr-3">
                          <Image
                            src={method.icon || "/placeholder.svg"}
                            alt={method.name}
                            fill
                            className="object-contain"
                          />
                        </div>
                        <div>
                          <div className="font-medium">{method.name}</div>
                          <div className="text-sm text-gray-500">{method.description}</div>
                        </div>
                      </Label>
                    </div>
                  ))}
                </RadioGroup>
              </div>
            </div>

            <div className="flex justify-between items-center">
              <Button variant="outline" asChild>
                <Link href="/gio-hang">
                  <ChevronLeft className="mr-1 h-4 w-4" />
                  Quay lại giỏ hàng
                </Link>
              </Button>

              <Button type="submit" disabled={isSubmitting}>
                {isSubmitting ? (
                  <>
                    <LoadingIndicator size="sm" text="" />
                    <span className="ml-2">Đang xử lý...</span>
                  </>
                ) : (
                  <>
                    Hoàn tất đơn hàng
                    <ChevronRight className="ml-1 h-4 w-4" />
                  </>
                )}
              </Button>
            </div>
          </form>
        </div>

        <div className="lg:col-span-1">
          <div className="bg-white rounded-lg shadow-sm border p-4 sticky top-4">
            <h2 className="text-lg font-bold mb-4 flex items-center">
              <ShoppingBag className="h-5 w-5 mr-2" />
              Đơn hàng của bạn
            </h2>

            <div className="space-y-4 mb-4">
              {cartItems.map((item) => (
                <div key={item.id} className="flex space-x-3">
                  <div className="relative h-16 w-16 rounded-md overflow-hidden flex-shrink-0">
                    <Image src={item.image || "/placeholder.svg"} alt={item.name} fill className="object-cover" />
                    <div className="absolute top-0 right-0 bg-gray-800 text-white text-xs rounded-bl-md px-1">
                      {item.quantity}
                    </div>
                  </div>
                  <div className="flex-1">
                    <h3 className="text-sm font-medium line-clamp-2">{item.name}</h3>
                    <div className="text-xs text-gray-500 mt-1">
                      <span>Màu: {item.color}</span>
                      <span className="mx-1">|</span>
                      <span>Size: {item.size}</span>
                    </div>
                    <div className="text-sm font-medium mt-1">
                      {new Intl.NumberFormat("vi-VN", { style: "currency", currency: "VND" }).format(item.salePrice)}
                      {item.salePrice < item.price && (
                        <span className="text-xs text-gray-500 line-through ml-1">
                          {new Intl.NumberFormat("vi-VN", { style: "currency", currency: "VND" }).format(item.price)}
                        </span>
                      )}
                    </div>
                  </div>
                </div>
              ))}
            </div>

            <Separator className="my-4" />

            <div className="space-y-3 text-sm">
              <div className="flex justify-between">
                <span className="text-gray-600">
                  Tạm tính ({cartItems.reduce((sum, item) => sum + item.quantity, 0)} sản phẩm):
                </span>
                <span className="font-medium">
                  {new Intl.NumberFormat("vi-VN", { style: "currency", currency: "VND" }).format(subtotal)}
                </span>
              </div>

              <div className="flex justify-between">
                <span className="text-gray-600">Phí vận chuyển:</span>
                <span className="font-medium">
                  {shipping === 0
                    ? "Miễn phí"
                    : new Intl.NumberFormat("vi-VN", { style: "currency", currency: "VND" }).format(shipping)}
                </span>
              </div>

              {discount > 0 && (
                <div className="flex justify-between text-green-600">
                  <span>Giảm giá:</span>
                  <span className="font-medium">
                    -{new Intl.NumberFormat("vi-VN", { style: "currency", currency: "VND" }).format(discount)}
                  </span>
                </div>
              )}

              <Separator />

              <div className="flex justify-between text-base font-bold">
                <span>Tổng cộng:</span>
                <span className="text-primary">
                  {new Intl.NumberFormat("vi-VN", { style: "currency", currency: "VND" }).format(total)}
                </span>
              </div>
            </div>

            <div className="mt-4 p-3 bg-green-50 text-green-700 rounded-md text-sm flex items-start">
              <CheckCircle2 className="h-5 w-5 mr-2 flex-shrink-0" />
              <p>Đơn hàng của bạn đủ điều kiện để được miễn phí vận chuyển với đơn hàng từ 300.000₫</p>
            </div>
          </div>
        </div>
      </div>

      <OrderSuccessDialog open={showSuccessDialog} onOpenChange={setShowSuccessDialog} />
    </div>
  )
}
