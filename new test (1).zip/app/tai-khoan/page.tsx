"use client"

import type React from "react"

import { useState, useEffect } from "react"
import Link from "next/link"
import Image from "next/image"
import {
  User,
  Package,
  Heart,
  Settings,
  LogOut,
  MapPin,
  Phone,
  Mail,
  Edit,
  ShoppingBag,
  Clock,
  CheckCircle,
  Truck,
  AlertCircle,
  X,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { Separator } from "@/components/ui/separator"
import { LoadingIndicator } from "@/components/loading-indicator"

// Mock data - Thay thế bằng dữ liệu thực từ API
const userData = {
  id: "1",
  name: "Nguyễn Văn A",
  email: "nguyenvana@example.com",
  phone: "0987654321",
  avatar: "/placeholder.svg?height=100&width=100",
  address: "123 Đường ABC, Phường XYZ, Quận 1, TP. Hồ Chí Minh",
  memberSince: "2023-01-15",
  orders: [
    {
      id: "DH123456",
      date: "2023-05-20",
      total: 548000,
      status: "completed",
      items: [
        {
          id: "1",
          name: "Áo Thun Unisex Cotton Form Rộng",
          image: "/placeholder.svg?height=80&width=80",
          price: 149000,
          quantity: 2,
        },
        {
          id: "2",
          name: "Quần Jean Nam Slim Fit",
          image: "/placeholder.svg?height=80&width=80",
          price: 250000,
          quantity: 1,
        },
      ],
    },
    {
      id: "DH123457",
      date: "2023-06-10",
      total: 399000,
      status: "shipping",
      items: [
        {
          id: "3",
          name: "Áo Khoác Denim Unisex",
          image: "/placeholder.svg?height=80&width=80",
          price: 399000,
          quantity: 1,
        },
      ],
    },
    {
      id: "DH123458",
      date: "2023-06-25",
      total: 159000,
      status: "processing",
      items: [
        {
          id: "4",
          name: "Áo Thun Nữ Form Rộng",
          image: "/placeholder.svg?height=80&width=80",
          price: 159000,
          quantity: 1,
        },
      ],
    },
  ],
  wishlist: [
    {
      id: "5",
      name: "Váy Liền Nữ Dáng Xòe",
      image: "/placeholder.svg?height=120&width=120",
      price: 350000,
      salePrice: 299000,
      discount: 15,
    },
    {
      id: "6",
      name: "Áo Sơ Mi Nam Dài Tay",
      image: "/placeholder.svg?height=120&width=120",
      price: 299000,
      salePrice: 249000,
      discount: 17,
    },
  ],
}

// Ánh xạ trạng thái đơn hàng
const orderStatusMap: Record<string, { label: string; color: string; icon: React.ReactNode }> = {
  processing: {
    label: "Đang xử lý",
    color: "bg-blue-100 text-blue-800",
    icon: <Clock className="h-4 w-4" />,
  },
  shipping: {
    label: "Đang giao hàng",
    color: "bg-amber-100 text-amber-800",
    icon: <Truck className="h-4 w-4" />,
  },
  completed: {
    label: "Đã giao hàng",
    color: "bg-green-100 text-green-800",
    icon: <CheckCircle className="h-4 w-4" />,
  },
  cancelled: {
    label: "Đã hủy",
    color: "bg-red-100 text-red-800",
    icon: <X className="h-4 w-4" />,
  },
  refunded: {
    label: "Đã hoàn tiền",
    color: "bg-purple-100 text-purple-800",
    icon: <AlertCircle className="h-4 w-4" />,
  },
}

export default function AccountPage() {
  const [isLoading, setIsLoading] = useState(true)
  const [activeTab, setActiveTab] = useState("overview")

  useEffect(() => {
    // Giả lập fetch dữ liệu
    const fetchData = async () => {
      await new Promise((resolve) => setTimeout(resolve, 800))
      setIsLoading(false)
    }

    fetchData()
  }, [])

  if (isLoading) {
    return (
      <div className="container mx-auto px-4 py-8">
        <LoadingIndicator text="Đang tải thông tin tài khoản..." />
      </div>
    )
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-2xl font-bold mb-6 flex items-center">
        <User className="mr-2 h-6 w-6" />
        Tài khoản của tôi
      </h1>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <div className="md:col-span-1">
          <Card>
            <CardHeader className="flex flex-row items-center gap-4 pb-2">
              <Avatar className="h-16 w-16">
                <AvatarImage src={userData.avatar || "/placeholder.svg"} alt={userData.name} />
                <AvatarFallback>{userData.name.charAt(0)}</AvatarFallback>
              </Avatar>
              <div>
                <CardTitle>{userData.name}</CardTitle>
                <CardDescription>
                  Thành viên từ {new Date(userData.memberSince).toLocaleDateString("vi-VN")}
                </CardDescription>
              </div>
            </CardHeader>
            <CardContent className="pt-4">
              <div className="space-y-2 text-sm">
                <div className="flex items-center">
                  <Mail className="h-4 w-4 mr-2 text-gray-500" />
                  <span>{userData.email}</span>
                </div>
                <div className="flex items-center">
                  <Phone className="h-4 w-4 mr-2 text-gray-500" />
                  <span>{userData.phone}</span>
                </div>
                <div className="flex items-start">
                  <MapPin className="h-4 w-4 mr-2 text-gray-500 mt-0.5" />
                  <span>{userData.address}</span>
                </div>
              </div>
            </CardContent>
            <CardFooter>
              <Button variant="outline" className="w-full" asChild>
                <Link href="/tai-khoan/chinh-sua">
                  <Edit className="mr-2 h-4 w-4" />
                  Chỉnh sửa thông tin
                </Link>
              </Button>
            </CardFooter>
          </Card>

          <div className="mt-4 bg-white rounded-lg shadow-sm border overflow-hidden">
            <div className="divide-y">
              <Link
                href="/tai-khoan"
                className={`flex items-center p-3 hover:bg-gray-50 ${activeTab === "overview" ? "bg-gray-50 text-primary font-medium" : ""}`}
                onClick={() => setActiveTab("overview")}
              >
                <User className="h-5 w-5 mr-3" />
                Tổng quan tài khoản
              </Link>
              <Link
                href="/tai-khoan?tab=orders"
                className={`flex items-center p-3 hover:bg-gray-50 ${activeTab === "orders" ? "bg-gray-50 text-primary font-medium" : ""}`}
                onClick={() => setActiveTab("orders")}
              >
                <Package className="h-5 w-5 mr-3" />
                Đơn hàng của tôi
              </Link>
              <Link
                href="/tai-khoan?tab=wishlist"
                className={`flex items-center p-3 hover:bg-gray-50 ${activeTab === "wishlist" ? "bg-gray-50 text-primary font-medium" : ""}`}
                onClick={() => setActiveTab("wishlist")}
              >
                <Heart className="h-5 w-5 mr-3" />
                Danh sách yêu thích
              </Link>
              <Link
                href="/tai-khoan?tab=settings"
                className={`flex items-center p-3 hover:bg-gray-50 ${activeTab === "settings" ? "bg-gray-50 text-primary font-medium" : ""}`}
                onClick={() => setActiveTab("settings")}
              >
                <Settings className="h-5 w-5 mr-3" />
                Cài đặt tài khoản
              </Link>
              <Link href="/dang-xuat" className="flex items-center p-3 hover:bg-gray-50 text-red-600">
                <LogOut className="h-5 w-5 mr-3" />
                Đăng xuất
              </Link>
            </div>
          </div>
        </div>

        <div className="md:col-span-3">
          <Tabs defaultValue="overview" value={activeTab} onValueChange={setActiveTab}>
            <TabsList className="w-full justify-start border-b mb-6">
              <TabsTrigger value="overview">Tổng quan</TabsTrigger>
              <TabsTrigger value="orders">Đơn hàng</TabsTrigger>
              <TabsTrigger value="wishlist">Yêu thích</TabsTrigger>
              <TabsTrigger value="settings">Cài đặt</TabsTrigger>
            </TabsList>

            <TabsContent value="overview" className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <ShoppingBag className="h-5 w-5 mr-2" />
                    Đơn hàng gần đây
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  {userData.orders.length > 0 ? (
                    <div className="space-y-4">
                      {userData.orders.slice(0, 2).map((order) => (
                        <div key={order.id} className="border rounded-lg p-4">
                          <div className="flex justify-between items-center mb-3">
                            <div>
                              <span className="font-medium">Đơn hàng #{order.id}</span>
                              <span className="text-sm text-gray-500 ml-2">
                                {new Date(order.date).toLocaleDateString("vi-VN")}
                              </span>
                            </div>
                            <Badge className={orderStatusMap[order.status].color}>
                              <span className="flex items-center">
                                {orderStatusMap[order.status].icon}
                                <span className="ml-1">{orderStatusMap[order.status].label}</span>
                              </span>
                            </Badge>
                          </div>

                          <div className="space-y-2">
                            {order.items.map((item) => (
                              <div key={item.id} className="flex items-center">
                                <div className="relative h-12 w-12 rounded-md overflow-hidden flex-shrink-0">
                                  <Image
                                    src={item.image || "/placeholder.svg"}
                                    alt={item.name}
                                    fill
                                    className="object-cover"
                                  />
                                </div>
                                <div className="ml-3 flex-1">
                                  <div className="text-sm font-medium line-clamp-1">{item.name}</div>
                                  <div className="text-xs text-gray-500">
                                    {new Intl.NumberFormat("vi-VN", { style: "currency", currency: "VND" }).format(
                                      item.price,
                                    )}{" "}
                                    x {item.quantity}
                                  </div>
                                </div>
                              </div>
                            ))}
                          </div>

                          <Separator className="my-3" />

                          <div className="flex justify-between items-center">
                            <div className="font-medium">
                              Tổng cộng:{" "}
                              {new Intl.NumberFormat("vi-VN", { style: "currency", currency: "VND" }).format(
                                order.total,
                              )}
                            </div>
                            <Button variant="outline" size="sm" asChild>
                              <Link href={`/tai-khoan/don-hang/${order.id}`}>Xem chi tiết</Link>
                            </Button>
                          </div>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <div className="text-center py-6 text-gray-500">Bạn chưa có đơn hàng nào</div>
                  )}
                </CardContent>
                <CardFooter>
                  <Button variant="outline" className="w-full" asChild>
                    <Link href="/tai-khoan?tab=orders">Xem tất cả đơn hàng</Link>
                  </Button>
                </CardFooter>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Heart className="h-5 w-5 mr-2" />
                    Sản phẩm yêu thích
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  {userData.wishlist.length > 0 ? (
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      {userData.wishlist.map((item) => (
                        <div key={item.id} className="border rounded-lg p-3 flex">
                          <div className="relative h-20 w-20 rounded-md overflow-hidden flex-shrink-0">
                            <Image
                              src={item.image || "/placeholder.svg"}
                              alt={item.name}
                              fill
                              className="object-cover"
                            />
                          </div>
                          <div className="ml-3 flex-1">
                            <div className="font-medium line-clamp-2">{item.name}</div>
                            <div className="flex items-center mt-1">
                              <span className="font-medium text-primary">
                                {new Intl.NumberFormat("vi-VN", { style: "currency", currency: "VND" }).format(
                                  item.salePrice,
                                )}
                              </span>
                              {item.discount > 0 && (
                                <span className="text-sm text-gray-500 line-through ml-2">
                                  {new Intl.NumberFormat("vi-VN", { style: "currency", currency: "VND" }).format(
                                    item.price,
                                  )}
                                </span>
                              )}
                            </div>
                            <Button variant="outline" size="sm" className="mt-2 h-8 w-full">
                              Thêm vào giỏ
                            </Button>
                          </div>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <div className="text-center py-6 text-gray-500">Bạn chưa có sản phẩm yêu thích nào</div>
                  )}
                </CardContent>
                <CardFooter>
                  <Button variant="outline" className="w-full" asChild>
                    <Link href="/tai-khoan?tab=wishlist">Xem tất cả sản phẩm yêu thích</Link>
                  </Button>
                </CardFooter>
              </Card>
            </TabsContent>

            <TabsContent value="orders">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Package className="h-5 w-5 mr-2" />
                    Đơn hàng của tôi
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  {userData.orders.length > 0 ? (
                    <div className="space-y-4">
                      {userData.orders.map((order) => (
                        <div key={order.id} className="border rounded-lg p-4">
                          <div className="flex justify-between items-center mb-3">
                            <div>
                              <span className="font-medium">Đơn hàng #{order.id}</span>
                              <span className="text-sm text-gray-500 ml-2">
                                {new Date(order.date).toLocaleDateString("vi-VN")}
                              </span>
                            </div>
                            <Badge className={orderStatusMap[order.status].color}>
                              <span className="flex items-center">
                                {orderStatusMap[order.status].icon}
                                <span className="ml-1">{orderStatusMap[order.status].label}</span>
                              </span>
                            </Badge>
                          </div>

                          <div className="space-y-2">
                            {order.items.map((item) => (
                              <div key={item.id} className="flex items-center">
                                <div className="relative h-12 w-12 rounded-md overflow-hidden flex-shrink-0">
                                  <Image
                                    src={item.image || "/placeholder.svg"}
                                    alt={item.name}
                                    fill
                                    className="object-cover"
                                  />
                                </div>
                                <div className="ml-3 flex-1">
                                  <div className="text-sm font-medium line-clamp-1">{item.name}</div>
                                  <div className="text-xs text-gray-500">
                                    {new Intl.NumberFormat("vi-VN", { style: "currency", currency: "VND" }).format(
                                      item.price,
                                    )}{" "}
                                    x {item.quantity}
                                  </div>
                                </div>
                              </div>
                            ))}
                          </div>

                          <Separator className="my-3" />

                          <div className="flex justify-between items-center">
                            <div className="font-medium">
                              Tổng cộng:{" "}
                              {new Intl.NumberFormat("vi-VN", { style: "currency", currency: "VND" }).format(
                                order.total,
                              )}
                            </div>
                            <Button variant="outline" size="sm" asChild>
                              <Link href={`/tai-khoan/don-hang/${order.id}`}>Xem chi tiết</Link>
                            </Button>
                          </div>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <div className="text-center py-6 text-gray-500">Bạn chưa có đơn hàng nào</div>
                  )}
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="wishlist">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Heart className="h-5 w-5 mr-2" />
                    Danh sách yêu thích
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  {userData.wishlist.length > 0 ? (
                    <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
                      {userData.wishlist.map((item) => (
                        <div key={item.id} className="border rounded-lg p-3">
                          <div className="relative h-40 w-full rounded-md overflow-hidden">
                            <Image
                              src={item.image || "/placeholder.svg"}
                              alt={item.name}
                              fill
                              className="object-cover"
                            />
                          </div>
                          <div className="mt-3">
                            <div className="font-medium line-clamp-2">{item.name}</div>
                            <div className="flex items-center mt-1">
                              <span className="font-medium text-primary">
                                {new Intl.NumberFormat("vi-VN", { style: "currency", currency: "VND" }).format(
                                  item.salePrice,
                                )}
                              </span>
                              {item.discount > 0 && (
                                <span className="text-sm text-gray-500 line-through ml-2">
                                  {new Intl.NumberFormat("vi-VN", { style: "currency", currency: "VND" }).format(
                                    item.price,
                                  )}
                                </span>
                              )}
                            </div>
                            <div className="flex space-x-2 mt-3">
                              <Button variant="default" size="sm" className="flex-1">
                                Thêm vào giỏ
                              </Button>
                              <Button variant="outline" size="sm" className="w-10 p-0">
                                <X className="h-4 w-4" />
                              </Button>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <div className="text-center py-6 text-gray-500">Bạn chưa có sản phẩm yêu thích nào</div>
                  )}
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="settings">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Settings className="h-5 w-5 mr-2" />
                    Cài đặt tài khoản
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div>
                      <h3 className="font-medium mb-2">Thông tin cá nhân</h3>
                      <Button variant="outline" asChild>
                        <Link href="/tai-khoan/chinh-sua">Chỉnh sửa thông tin cá nhân</Link>
                      </Button>
                    </div>

                    <Separator />

                    <div>
                      <h3 className="font-medium mb-2">Bảo mật</h3>
                      <Button variant="outline" asChild>
                        <Link href="/tai-khoan/doi-mat-khau">Đổi mật khẩu</Link>
                      </Button>
                    </div>

                    <Separator />

                    <div>
                      <h3 className="font-medium mb-2">Thông báo</h3>
                      <div className="space-y-2">
                        <div className="flex items-center justify-between">
                          <Label htmlFor="email-notifications">Thông báo qua email</Label>
                          <Switch id="email-notifications" />
                        </div>
                        <div className="flex items-center justify-between">
                          <Label htmlFor="sms-notifications">Thông báo qua SMS</Label>
                          <Switch id="sms-notifications" />
                        </div>
                        <div className="flex items-center justify-between">
                          <Label htmlFor="marketing-emails">Email quảng cáo</Label>
                          <Switch id="marketing-emails" />
                        </div>
                      </div>
                    </div>

                    <Separator />

                    <div>
                      <h3 className="font-medium mb-2">Xóa tài khoản</h3>
                      <p className="text-sm text-gray-500 mb-2">
                        Khi xóa tài khoản, tất cả dữ liệu của bạn sẽ bị xóa vĩnh viễn và không thể khôi phục.
                      </p>
                      <Button variant="destructive">Xóa tài khoản</Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </div>
  )
}

// Thêm component Label và Switch
function Label({ htmlFor, children }: { htmlFor: string; children: React.ReactNode }) {
  return (
    <label htmlFor={htmlFor} className="text-sm font-medium">
      {children}
    </label>
  )
}

function Switch({ id }: { id: string }) {
  const [checked, setChecked] = useState(false)

  return (
    <button
      id={id}
      role="switch"
      aria-checked={checked}
      onClick={() => setChecked(!checked)}
      className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-primary ${
        checked ? "bg-primary" : "bg-gray-200"
      }`}
    >
      <span
        className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
          checked ? "translate-x-6" : "translate-x-1"
        }`}
      />
    </button>
  )
}
