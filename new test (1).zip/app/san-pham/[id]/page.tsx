import { Suspense } from "react"
import { notFound } from "next/navigation"
import Link from "next/link"
import { Star, Truck, Shield, RotateCcw, ChevronRight } from "lucide-react"
import { Badge } from "@/components/ui/badge"
import { Separator } from "@/components/ui/separator"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { ProductReviews } from "@/components/product-reviews"
import { ProductSuggestions } from "@/components/product-suggestions"
import { SizeSelector } from "@/components/size-selector"
import { ColorSelector } from "@/components/color-selector"
import { QuantitySelector } from "@/components/quantity-selector"
import { AddToCartButton } from "@/components/add-to-cart-button"
import { WishlistButton } from "@/components/wishlist-button"
import { ShareButton } from "@/components/share-button"
import { ProductImageGallery } from "@/components/product-image-gallery"
import { ProductSpecifications } from "@/components/product-specifications"
import { LoadingIndicator } from "@/components/loading-indicator"

// Mock data - Thay thế bằng dữ liệu thực từ API
const product = {
  id: "1",
  name: "Áo Thun Unisex Cotton Form Rộng",
  price: 199000,
  salePrice: 149000,
  discount: 25,
  description:
    "Áo thun unisex cotton form rộng với thiết kế đơn giản, hiện đại. Chất liệu cotton 100% mềm mại, thấm hút mồ hôi tốt, thoáng mát. Phù hợp cho cả nam và nữ.",
  images: [
    "/placeholder.svg?height=600&width=400",
    "/placeholder.svg?height=600&width=400",
    "/placeholder.svg?height=600&width=400",
    "/placeholder.svg?height=600&width=400",
  ],
  colors: ["Đen", "Trắng", "Xám", "Xanh Navy"],
  sizes: ["S", "M", "L", "XL", "XXL"],
  stock: 50,
  rating: 4.5,
  reviewCount: 120,
  specifications: {
    "Chất liệu": "Cotton 100%",
    "Kiểu dáng": "Form rộng (Oversize)",
    "Xuất xứ": "Việt Nam",
    "Phù hợp": "Đi chơi, đi học, đi làm",
    "Bảo quản": "Giặt máy ở nhiệt độ thường, không tẩy, ủi ở nhiệt độ thấp",
  },
  category: "Áo",
  tags: ["áo thun", "unisex", "cotton", "form rộng"],
  isNew: true,
  isBestSeller: true,
}

export default function ProductPage({ params }: { params: { id: string } }) {
  // Trong thực tế, bạn sẽ fetch dữ liệu sản phẩm dựa trên params.id
  // Nếu không tìm thấy sản phẩm, trả về notFound()
  if (!product) {
    notFound()
  }

  return (
    <div className="container px-4 py-6 mx-auto">
      {/* Breadcrumb */}
      <div className="flex items-center text-sm text-gray-500 mb-4">
        <Link href="/" className="hover:text-primary">
          Trang chủ
        </Link>
        <ChevronRight className="h-4 w-4 mx-1" />
        <Link href="/danh-muc/tat-ca" className="hover:text-primary">
          Sản phẩm
        </Link>
        <ChevronRight className="h-4 w-4 mx-1" />
        <Link href={`/danh-muc/${product.category.toLowerCase()}`} className="hover:text-primary">
          {product.category}
        </Link>
        <ChevronRight className="h-4 w-4 mx-1" />
        <span className="text-gray-700 truncate">{product.name}</span>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        {/* Hình ảnh sản phẩm */}
        <Suspense fallback={<LoadingIndicator />}>
          <ProductImageGallery images={product.images} productName={product.name} />
        </Suspense>

        {/* Thông tin sản phẩm */}
        <div className="space-y-4">
          <div className="flex items-center space-x-2">
            {product.isNew && <Badge className="bg-blue-500 hover:bg-blue-600">Mới</Badge>}
            {product.isBestSeller && <Badge className="bg-amber-500 hover:bg-amber-600">Bán chạy</Badge>}
            {product.discount > 0 && <Badge className="bg-red-500 hover:bg-red-600">-{product.discount}%</Badge>}
          </div>

          <h1 className="text-2xl font-bold">{product.name}</h1>

          <div className="flex items-center space-x-2">
            <div className="flex items-center">
              {Array(5)
                .fill(0)
                .map((_, i) => (
                  <Star
                    key={i}
                    className={`h-4 w-4 ${i < Math.floor(product.rating) ? "text-yellow-400 fill-yellow-400" : "text-gray-300"}`}
                  />
                ))}
              {product.rating % 1 > 0 && (
                <div className="relative">
                  <Star className="h-4 w-4 text-gray-300" />
                  <div
                    className="absolute top-0 left-0 overflow-hidden"
                    style={{ width: `${(product.rating % 1) * 100}%` }}
                  >
                    <Star className="h-4 w-4 text-yellow-400 fill-yellow-400" />
                  </div>
                </div>
              )}
            </div>
            <span className="text-sm text-gray-500">
              {product.rating} ({product.reviewCount} đánh giá)
            </span>
            <Separator orientation="vertical" className="h-4" />
            <span className="text-sm text-gray-500">Đã bán: 250+</span>
          </div>

          <div className="flex items-center space-x-2">
            {product.salePrice < product.price ? (
              <>
                <span className="text-2xl font-bold text-red-600">
                  {new Intl.NumberFormat("vi-VN", { style: "currency", currency: "VND" }).format(product.salePrice)}
                </span>
                <span className="text-lg text-gray-500 line-through">
                  {new Intl.NumberFormat("vi-VN", { style: "currency", currency: "VND" }).format(product.price)}
                </span>
                <Badge className="bg-red-500 hover:bg-red-600">
                  Tiết kiệm{" "}
                  {new Intl.NumberFormat("vi-VN", { style: "currency", currency: "VND" }).format(
                    product.price - product.salePrice,
                  )}
                </Badge>
              </>
            ) : (
              <span className="text-2xl font-bold text-gray-900">
                {new Intl.NumberFormat("vi-VN", { style: "currency", currency: "VND" }).format(product.price)}
              </span>
            )}
          </div>

          <Separator />

          <div className="space-y-4">
            <div>
              <h3 className="text-sm font-medium text-gray-700 mb-2">Màu sắc</h3>
              <ColorSelector colors={product.colors} />
            </div>

            <div>
              <h3 className="text-sm font-medium text-gray-700 mb-2">Kích thước</h3>
              <SizeSelector sizes={product.sizes} />
            </div>

            <div>
              <h3 className="text-sm font-medium text-gray-700 mb-2">Số lượng</h3>
              <div className="flex items-center space-x-2">
                <QuantitySelector max={product.stock} />
                <span className="text-sm text-gray-500">Còn {product.stock} sản phẩm</span>
              </div>
            </div>
          </div>

          <div className="flex flex-col sm:flex-row gap-3 pt-2">
            <AddToCartButton productId={product.id} className="flex-1" />
            <WishlistButton productId={product.id} />
            <ShareButton productId={product.id} />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 mt-4">
            <div className="flex items-center p-3 border rounded-lg">
              <Truck className="h-5 w-5 text-primary mr-2" />
              <div>
                <p className="text-xs font-medium">Giao hàng miễn phí</p>
                <p className="text-xs text-gray-500">Cho đơn từ 300k</p>
              </div>
            </div>
            <div className="flex items-center p-3 border rounded-lg">
              <Shield className="h-5 w-5 text-primary mr-2" />
              <div>
                <p className="text-xs font-medium">Bảo hành 30 ngày</p>
                <p className="text-xs text-gray-500">Đổi trả dễ dàng</p>
              </div>
            </div>
            <div className="flex items-center p-3 border rounded-lg">
              <RotateCcw className="h-5 w-5 text-primary mr-2" />
              <div>
                <p className="text-xs font-medium">Hoàn tiền 100%</p>
                <p className="text-xs text-gray-500">Nếu hàng lỗi</p>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="mt-12">
        <Tabs defaultValue="description">
          <TabsList className="w-full justify-start border-b">
            <TabsTrigger value="description">Mô tả</TabsTrigger>
            <TabsTrigger value="specifications">Thông số</TabsTrigger>
            <TabsTrigger value="reviews">Đánh giá ({product.reviewCount})</TabsTrigger>
          </TabsList>
          <TabsContent value="description" className="py-4">
            <div className="prose max-w-none">
              <p>{product.description}</p>
              <h3>Đặc điểm nổi bật</h3>
              <ul>
                <li>Chất liệu cotton 100% mềm mại, thấm hút mồ hôi tốt</li>
                <li>Form rộng thoải mái, phù hợp với nhiều vóc dáng</li>
                <li>Thiết kế đơn giản, dễ phối đồ</li>
                <li>Đường may tỉ mỉ, chắc chắn</li>
                <li>Màu sắc đa dạng, phù hợp với nhiều phong cách</li>
              </ul>
              <h3>Hướng dẫn bảo quản</h3>
              <ul>
                <li>Giặt máy ở nhiệt độ thường</li>
                <li>Không sử dụng chất tẩy</li>
                <li>Ủi ở nhiệt độ thấp</li>
                <li>Phơi trong bóng râm</li>
              </ul>
            </div>
          </TabsContent>
          <TabsContent value="specifications" className="py-4">
            <ProductSpecifications specifications={product.specifications} />
          </TabsContent>
          <TabsContent value="reviews" className="py-4">
            <ProductReviews productId={product.id} />
          </TabsContent>
        </Tabs>
      </div>

      <div className="mt-12">
        <h2 className="text-xl font-bold mb-4">Sản phẩm tương tự</h2>
        <Suspense fallback={<LoadingIndicator />}>
          <ProductSuggestions productId={product.id} category={product.category} />
        </Suspense>
      </div>
    </div>
  )
}
