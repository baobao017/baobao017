import Link from "next/link"
import { ShoppingBag, Search, Heart, User } from "lucide-react"

import { Button } from "@/components/ui/button"
import MobileNavigation from "@/components/mobile-navigation"
import FeaturedProducts from "@/components/featured-products"
import CollectionGrid from "@/components/collection-grid"
import SideMenu from "@/components/side-menu"
import BrandHeader from "@/components/brand-header"
import Footer from "@/components/footer"
import FlashSale from "@/components/flash-sale"
import PromoBanner from "@/components/promo-banner"
import CategoryTabs from "@/components/category-tabs"

export default function HomePage() {
  return (
    <main className="pb-16">
      {/* Header */}
      <header className="sticky top-0 z-50 bg-white border-b">
        <div className="container flex items-center justify-between h-14 px-4">
          <SideMenu />

          <Link href="/" className="font-bold text-xl">
            ThoiTrangViet
          </Link>

          <div className="flex items-center gap-2">
            <Link href="/tim-kiem">
              <Button variant="ghost" size="icon" className="relative">
                <Search className="h-5 w-5" />
                <span className="sr-only">Tìm kiếm</span>
              </Button>
            </Link>

            <Link href="/yeu-thich">
              <Button variant="ghost" size="icon" className="relative">
                <Heart className="h-5 w-5" />
                <span className="sr-only">Yêu thích</span>
              </Button>
            </Link>

            <Link href="/tai-khoan">
              <Button variant="ghost" size="icon" className="relative">
                <User className="h-5 w-5" />
                <span className="sr-only">Tài khoản</span>
              </Button>
            </Link>

            <Link href="/gio-hang">
              <Button variant="ghost" size="icon" className="relative">
                <ShoppingBag className="h-5 w-5" />
                <span className="absolute -top-1 -right-1 bg-primary text-primary-foreground text-xs rounded-full h-5 w-5 flex items-center justify-center">
                  5
                </span>
                <span className="sr-only">Giỏ hàng</span>
              </Button>
            </Link>
          </div>
        </div>
      </header>

      {/* Thương hiệu và Banner */}
      <BrandHeader />

      {/* Banner khuyến mãi */}
      <PromoBanner />

      {/* Danh mục sản phẩm */}
      <CategoryTabs />

      {/* Flash Sale */}
      <FlashSale />

      {/* Sản phẩm nổi bật */}
      <div className="mt-8 px-4">
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-xl font-bold">Sản phẩm nổi bật</h2>
          <Link href="/danh-muc/tat-ca" className="text-sm text-primary">
            Xem tất cả
          </Link>
        </div>
        <FeaturedProducts layout="grid" />
      </div>

      {/* Bộ sưu tập */}
      <div className="mt-8 px-4">
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-xl font-bold">Bộ sưu tập</h2>
          <Link href="/bo-suu-tap" className="text-sm text-primary">
            Xem tất cả
          </Link>
        </div>
        <CollectionGrid />
      </div>

      {/* Footer */}
      <Footer />

      {/* Mobile Navigation */}
      <MobileNavigation />
    </main>
  )
}
